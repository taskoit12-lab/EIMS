<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';

$conn = getConnection();

// Saara stock lao, product aur location details ke saath
$stock = mysqli_query($conn, "
    SELECT ii.*, p.name as product_name, p.sku, p.reorder_point, p.unit_of_measure,
           w.name as warehouse_name, l.zone_code, l.bin_code
    FROM inventory_items ii
    JOIN products p ON ii.product_id = p.product_id
    JOIN locations l ON ii.location_id = l.location_id
    JOIN warehouses w ON l.warehouse_id = w.warehouse_id
    ORDER BY p.name
");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-archive"></i> Stock / Inventory</h4>
    <div>
        <a href="stock_in.php" class="btn btn-success me-2">
            <i class="bi bi-box-arrow-in-down"></i> Stock IN
        </a>
        <a href="stock_out.php" class="btn btn-danger">
            <i class="bi bi-box-arrow-up"></i> Stock OUT
        </a>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>SKU</th>
                    <th>Product</th>
                    <th>Warehouse</th>
                    <th>Location</th>
                    <th>Qty on Hand</th>
                    <th>Qty Reserved</th>
                    <th>Available</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($stock) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($stock)): ?>
                    <?php $available = $row['quantity_on_hand'] - $row['quantity_reserved']; ?>
                    <tr>
                        <td><?php echo $row['sku']; ?></td>
                        <td><?php echo $row['product_name']; ?></td>
                        <td><?php echo $row['warehouse_name']; ?></td>
                        <td><?php echo ($row['zone_code'] ?? '-') . ' / ' . ($row['bin_code'] ?? '-'); ?></td>
                        <td><?php echo number_format($row['quantity_on_hand'], 2); ?> <?php echo $row['unit_of_measure']; ?></td>
                        <td><?php echo number_format($row['quantity_reserved'], 2); ?></td>
                        <td><?php echo number_format($available, 2); ?></td>
                        <td>
                            <?php if($row['quantity_on_hand'] <= $row['reorder_point']): ?>
                                <span class="badge bg-danger">Low Stock</span>
                            <?php else: ?>
                                <span class="badge bg-success">OK</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted">
                            Abhi koi stock nahi hai. <a href="stock_in.php">Pehla stock add karo</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>