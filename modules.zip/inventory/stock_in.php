<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
require_once '../../includes/auth.php'; 
requireRole(['ADMIN', 'MANAGER', 'STAFF']);
require_once '../../includes/audit.php';

$conn = getConnection();
$error = "";
$success = "";

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $product_id = (int)$_POST['product_id'];
    $location_id = (int)$_POST['location_id'];
    $quantity = (float)$_POST['quantity'];
    $notes = trim($_POST['notes']);
    $performed_by = $_SESSION['user_id'];

    if(empty($product_id) || empty($location_id) || $quantity <= 0) {
        $error = "Product, location aur quantity (0 se zyada) zaroori hain!";
    } else {
        $check = mysqli_prepare($conn, "SELECT item_id, quantity_on_hand FROM inventory_items WHERE product_id = ? AND location_id = ?");
        mysqli_stmt_bind_param($check, "ii", $product_id, $location_id);
        mysqli_stmt_execute($check);
        $existing = mysqli_fetch_assoc(mysqli_stmt_get_result($check));

        $qty_before = $existing ? $existing['quantity_on_hand'] : 0;
        $qty_after = $qty_before + $quantity;

        if($existing) {
            $upd = mysqli_prepare($conn, "UPDATE inventory_items SET quantity_on_hand = ? WHERE item_id = ?");
            mysqli_stmt_bind_param($upd, "di", $qty_after, $existing['item_id']);
            $ok = mysqli_stmt_execute($upd);
        } else {
            $ins = mysqli_prepare($conn, "INSERT INTO inventory_items (product_id, location_id, quantity_on_hand) VALUES (?, ?, ?)");
            mysqli_stmt_bind_param($ins, "iid", $product_id, $location_id, $qty_after);
            $ok = mysqli_stmt_execute($ins);
        }

        if($ok) {
            $mov = mysqli_prepare($conn, "INSERT INTO movement_records (product_id, from_location_id, to_location_id, movement_type, quantity, qty_before, qty_after, notes, performed_by) VALUES (?, NULL, ?, 'RECEIPT', ?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($mov, "iidddsi", $product_id, $location_id, $quantity, $qty_before, $qty_after, $notes, $performed_by);

           if(mysqli_stmt_execute($mov)) {
                logAudit($conn, $performed_by, 'inventory_items', $product_id, 'UPDATE', ['qty' => $qty_before], ['qty' => $qty_after, 'type' => 'RECEIPT']);
                 $ack = mysqli_prepare($conn, "UPDATE reorder_alerts SET alert_status='ACKNOWLEDGED', acknowledged_at=NOW() WHERE product_id=? AND location_id=? AND alert_status='ACTIVE'"); mysqli_stmt_bind_param($ack, "ii", $product_id, $location_id); mysqli_stmt_execute($ack);
                $success = "Stock IN successful! Naya quantity: " . number_format($qty_after, 2);
            } else {
                $error = "Movement record save nahi hua: " . mysqli_error($conn);
            }
        } else {
            $error = "Stock update nahi hua: " . mysqli_error($conn);
        }
    }
}

$products = mysqli_query($conn, "SELECT product_id, name, sku FROM products WHERE status='ACTIVE' ORDER BY name");
$locations = mysqli_query($conn, "SELECT l.location_id, w.name as warehouse_name, l.zone_code, l.bin_code FROM locations l JOIN warehouses w ON l.warehouse_id = w.warehouse_id ORDER BY w.name, l.zone_code");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-box-arrow-in-down text-success"></i> Stock IN (Receipt)</h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Product *</label>
                    <select name="product_id" class="form-select" required>
                        <option value="">-- Product Select Karo --</option>
                        <?php while($p = mysqli_fetch_assoc($products)): ?>
                        <option value="<?php echo $p['product_id']; ?>"><?php echo $p['name'] . ' (' . $p['sku'] . ')'; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Location *</label>
                    <select name="location_id" class="form-select" required>
                        <option value="">-- Location Select Karo --</option>
                        <?php while($l = mysqli_fetch_assoc($locations)): ?>
                        <option value="<?php echo $l['location_id']; ?>"><?php echo $l['warehouse_name'] . ' - ' . ($l['zone_code'] ?? '') . '/' . ($l['bin_code'] ?? ''); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Quantity *</label>
                    <input type="number" name="quantity" class="form-control" step="0.01" min="0.01" required>
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Notes</label>
                    <textarea name="notes" class="form-control" rows="2" placeholder="Jaise: Supplier se receive kiya"></textarea>
                </div>
            </div>
            <button type="submit" class="btn btn-success">
                <i class="bi bi-check-circle"></i> Stock IN Karo
            </button>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>