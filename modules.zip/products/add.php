<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
require_once '../../includes/auth.php';
requireRole(['ADMIN', 'MANAGER', 'STAFF']);
require_once '../../includes/audit.php';

$conn = getConnection();
$error = "";
$success = "";

// Form submit hone par
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $name = trim($_POST['name']);
    $sku = trim($_POST['sku']);
    $description = trim($_POST['description']);
    $category_id = (int)$_POST['category_id'];
    $unit_of_measure = $_POST['unit_of_measure'];
    $reorder_point = (float)$_POST['reorder_point'];
    $safety_stock = (float)$_POST['safety_stock'];
    $cost_price = (float)$_POST['cost_price'];
    $selling_price = (float)$_POST['selling_price'];
    $created_by = $_SESSION['user_id'];

    // Validation
    if(empty($name) || empty($sku) || empty($category_id) || empty($cost_price) || empty($selling_price)) {
        $error = "Starred (*) fields zaroori hain!";
    } else {
        // SKU duplicate check
        $check = mysqli_prepare($conn, "SELECT product_id FROM products WHERE sku = ?");
        mysqli_stmt_bind_param($check, "s", $sku);
        mysqli_stmt_execute($check);
        mysqli_stmt_store_result($check);

        if(mysqli_stmt_num_rows($check) > 0) {
            $error = "Yeh SKU pehle se exist karta hai!";
        } else {
            $stmt = mysqli_prepare($conn, "INSERT INTO products (name, sku, description, category_id, unit_of_measure, reorder_point, safety_stock, cost_price, selling_price, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "sssisddddi", $name, $sku, $description, $category_id, $unit_of_measure, $reorder_point, $safety_stock, $cost_price, $selling_price, $created_by);

            if(mysqli_stmt_execute($stmt)) {
               $new_id = mysqli_insert_id($conn);
               logAudit($conn, $created_by, 'products', $new_id, 'CREATE', null, ['name' => $name, 'sku' => $sku]);
               $success = "Product successfully add ho gaya!";
            } else {
                $error = "Kuch galat hua: " . mysqli_error($conn);
            }
        }
    }
}

// Categories lao
$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-plus-circle"></i> Naya Product Add Karo</h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Product Naam *</label>
                    <input type="text" name="name" class="form-control" placeholder="Jaise: HP Laptop" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">SKU *</label>
                    <input type="text" name="sku" class="form-control" placeholder="Jaise: HP-LAP-001" required>
                    <small class="text-muted">Unique code — har product ka alag hoga</small>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Category *</label>
                    <select name="category_id" class="form-select" required>
                        <option value="">-- Category Select Karo --</option>
                        <?php while($cat = mysqli_fetch_assoc($categories)): ?>
                        <option value="<?php echo $cat['category_id']; ?>">
                            <?php echo $cat['name']; ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Unit of Measure *</label>
                    <select name="unit_of_measure" class="form-select">
                        <option value="EACH">EACH (Piece)</option>
                        <option value="KG">KG</option>
                        <option value="LITRE">LITRE</option>
                        <option value="BOX">BOX</option>
                        <option value="METER">METER</option>
                    </select>
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="3" placeholder="Product ke baare mein..."></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Cost Price (Rs.) *</label>
                    <input type="number" name="cost_price" class="form-control" placeholder="0.00" step="0.01" min="0" required>
                    <small class="text-muted">Humne kitne mein kharida</small>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Selling Price (Rs.) *</label>
                    <input type="number" name="selling_price" class="form-control" placeholder="0.00" step="0.01" min="0" required>
                    <small class="text-muted">Hum kitne mein bechenge</small>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Reorder Point</label>
                    <input type="number" name="reorder_point" class="form-control" placeholder="0" step="0.01" min="0" value="0">
                    <small class="text-muted">Itne se kam hone par alert aayega</small>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Safety Stock</label>
                    <input type="number" name="safety_stock" class="form-control" placeholder="0" step="0.01" min="0" value="0">
                    <small class="text-muted">Minimum buffer stock</small>
                </div>
            </div>
            <button type="submit" class="btn btn-dark">
                <i class="bi bi-plus-circle"></i> Product Add Karo
            </button>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>