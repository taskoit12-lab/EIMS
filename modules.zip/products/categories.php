<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
require_once '../../includes/audit.php';

$conn = getConnection();
$error = "";
$success = "";

// Category add karo
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_category'])) {
    csrf_verify();
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    
    if(empty($name)) {
        $error = "Category naam zaroori hai!";
    } else {
        // Check karo duplicate toh nahi
        $check = mysqli_prepare($conn, "SELECT category_id FROM categories WHERE name = ?");
        mysqli_stmt_bind_param($check, "s", $name);
        mysqli_stmt_execute($check);
        mysqli_stmt_store_result($check);
        
        if(mysqli_stmt_num_rows($check) > 0) {
            $error = "Yeh category pehle se exist karti hai!";
        } else {
            $stmt = mysqli_prepare($conn, "INSERT INTO categories (name, description) VALUES (?, ?)");
            mysqli_stmt_bind_param($stmt, "ss", $name, $description);
            
            if(mysqli_stmt_execute($stmt)) {
                $success = "Category successfully add ho gayi!";
            } else {
                $error = "Kuch galat hua, dobara try karo!";
            }
        }
    }
}

// Category delete karo
if(isset($_GET['delete'])) {
    $delete_id = (int)$_GET['delete'];
    
    // Check karo koi product toh nahi is category mein
    $check = mysqli_prepare($conn, "SELECT product_id FROM products WHERE category_id = ?");
    mysqli_stmt_bind_param($check, "i", $delete_id);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);
    
    if(mysqli_stmt_num_rows($check) > 0) {
        $error = "Yeh category delete nahi ho sakti — isme products hain!";
    } else {
        $stmt = mysqli_prepare($conn, "DELETE FROM categories WHERE category_id = ?");
        mysqli_stmt_bind_param($stmt, "i", $delete_id);
        mysqli_stmt_execute($stmt);
        logAudit($conn, $_SESSION['user_id'], 'categories', $delete_id, 'DELETE', null, null);
        $success = "Category delete ho gayi!";
    }
}

// Saari categories lao
$categories = mysqli_query($conn, "SELECT c.*, COUNT(p.product_id) as product_count FROM categories c LEFT JOIN products p ON c.category_id = p.category_id GROUP BY c.category_id ORDER BY c.name");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-tags"></i> Categories</h4>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<div class="row">
    <!-- Add Category Form -->
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white">
                <h6 class="mb-0">Nayi Category Add Karo</h6>
            </div>
            <div class="card-body">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Category Naam *</label>
                        <input type="text" name="name" class="form-control" placeholder="Jaise: Electronics" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Description</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="Category ke baare mein..."></textarea>
                    </div>
                    <button type="submit" name="add_category" class="btn btn-dark w-100">
                        <i class="bi bi-plus-circle"></i> Add Category
                    </button>
                </form>
            </div>
        </div>
    </div>

    <!-- Categories List -->
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white">
                <h6 class="mb-0">Saari Categories</h6>
            </div>
            <div class="card-body">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>Naam</th>
                            <th>Description</th>
                            <th>Products</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($categories) > 0): ?>
                            <?php $i = 1; while($row = mysqli_fetch_assoc($categories)): ?>
                            <tr>
                                <td><?php echo $i++; ?></td>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo $row['description'] ?? '-'; ?></td>
                                <td>
                                    <span class="badge bg-primary">
                                        <?php echo $row['product_count']; ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if($row['product_count'] == 0): ?>
                                    <a href="?delete=<?php echo $row['category_id']; ?>" 
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('Delete karna chahte ho?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                    <?php else: ?>
                                    <span class="text-muted small">Delete nahi ho sakti</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted">
                                    Abhi koi category nahi hai
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>