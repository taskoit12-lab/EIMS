<?php
session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: " . BASE_URL . "login.php");
    exit();
}

if(!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$conn = getConnection();
$product_id = (int)$_GET['id'];
$copies = isset($_GET['copies']) ? max(1, min(50, (int)$_GET['copies'])) : 1;

$stmt = mysqli_prepare($conn, "SELECT * FROM products WHERE product_id = ?");
mysqli_stmt_bind_param($stmt, "i", $product_id);
mysqli_stmt_execute($stmt);
$product = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

mysqli_close($conn);

if(!$product) {
    header("Location: index.php");
    exit();
}

$barcode_url = "https://barcode.tec-it.com/barcode.ashx?data=" . urlencode($product['sku']) . "&code=Code128&dpi=96";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Barcode - <?php echo htmlspecialchars($product['sku']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 20px; }
        .label {
            border: 1px dashed #999;
            width: 220px;
            padding: 8px;
            text-align: center;
            display: inline-block;
            margin: 5px;
        }
        .label img { max-width: 100%; }
        @media print {
            .no-print { display: none; }
            .label { border: none; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="no-print mb-4">
            <div class="row align-items-end">
                <div class="col-md-3">
                    <label class="form-label">Kitne labels print karne hain?</label>
                    <input type="number" id="copiesInput" class="form-control" value="<?php echo $copies; ?>" min="1" max="50">
                </div>
                <div class="col-md-3">
                    <button onclick="updateCopies()" class="btn btn-outline-dark">Update</button>
                </div>
                <div class="col-md-6 text-end">
                    <button onclick="window.print()" class="btn btn-dark"><i class="bi bi-printer"></i> Print Labels</button>
                    <a href="index.php" class="btn btn-outline-secondary">Wapas Jao</a>
                </div>
            </div>
        </div>

        <div class="labels-wrapper">
            <?php for($i = 0; $i < $copies; $i++): ?>
            <div class="label">
                <strong><?php echo htmlspecialchars($product['name']); ?></strong><br>
                <img src="<?php echo $barcode_url; ?>" alt="Barcode">
                <div><?php echo htmlspecialchars($product['sku']); ?></div>
                <div>Rs. <?php echo number_format($product['selling_price'], 2); ?></div>
            </div>
            <?php endfor; ?>
        </div>
    </div>

    <script>
    function updateCopies() {
        var n = document.getElementById('copiesInput').value;
        window.location.href = "barcode.php?id=<?php echo $product_id; ?>&copies=" + n;
    }
    </script>
</body>
</html>