<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
require_once '../../includes/auth.php';
requireRole(['ADMIN', 'MANAGER', 'STAFF']);
require_once '../../includes/audit.php';

$conn = getConnection();
$error = "";
$success = "";

if(!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$product_id = (int)$_GET['id'];

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $name = trim($_POST['name']);
    $sku = trim($_POST['sku']);
    $description = trim($_POST['description']);
    $category_id = (int)$_POST['category_id'];
    $unit_of_measure = $_POST['unit_of_measure'];
    $reorder_point = (float)$_POST['reorder_point'];
    $safety_stock = (float)$_POST['safety_stock'];
    $cost_price = (float)$_POST['cost_price'];
    $selling_price = (float)$_POST['selling_price'];

    if(empty($name) || empty($sku) || empty($category_id) || empty($cost_price) || empty($selling_price)) {
        $error = "Starred (*) fields zaroori hain!";
    } else {
        $check = mysqli_prepare($conn, "SELECT product_id FROM products WHERE sku = ? AND product_id != ?");
        mysqli_stmt_bind_param($check, "si", $sku, $product_id);
        mysqli_stmt_execute($check);
        mysqli_stmt_store_result($check);

        if(mysqli_stmt_num_rows($check) > 0) {
            $error = "Yeh SKU pehle se kisi aur product mein hai!";
        } else {
            $stmt = mysqli_prepare($conn, "UPDATE products SET name=?, sku=?, description=?, category_id=?, unit_of_measure=?, reorder_point=?, safety_stock=?, cost_price=?, selling_price=? WHERE product_id=?");
            mysqli_stmt_bind_param($stmt, "sssisddddi", $name, $sku, $description, $category_id, $unit_of_measure, $reorder_point, $safety_stock, $cost_price, $selling_price, $product_id);

            if(mysqli_stmt_execute($stmt)) {
                logAudit($conn, $_SESSION['user_id'], 'products', $product_id, 'UPDATE', null, ['name' => $name, 'sku' => $sku, 'selling_price' => $selling_price]);
                $success = "Product update ho gaya!";
            } else {
                $error = "Kuch galat hua: " . mysqli_error($conn);
            }
        }
    }
}

$stmt = mysqli_prepare($conn, "SELECT * FROM products WHERE product_id = ?");
mysqli_stmt_bind_param($stmt, "i", $product_id);
mysqli_stmt_execute($stmt);
$product = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$product) {
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST' && !$error) {
    $stmt2 = mysqli_prepare($conn, "SELECT * FROM products WHERE product_id = ?");
    mysqli_stmt_bind_param($stmt2, "i", $product_id);
    mysqli_stmt_execute($stmt2);
    $product = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt2));
}

$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-pencil-square"></i> Product Edit Karo</h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Product Naam *</label>
                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($product['name']); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">SKU *</label>
                    <input type="text" name="sku" class="form-control" value="<?php echo htmlspecialchars($product['sku']); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Category *</label>
                    <select name="category_id" class="form-select" required>
                        <option value="">-- Category Select Karo --</option>
                        <?php while($cat = mysqli_fetch_assoc($categories)): ?>
                        <option value="<?php echo $cat['category_id']; ?>" <?php echo ($cat['category_id'] == $product['category_id']) ? 'selected' : ''; ?>>
                            <?php echo $cat['name']; ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Unit of Measure *</label>
                    <select name="unit_of_measure" class="form-select">
                        <?php foreach(['EACH','KG','LITRE','BOX','METER'] as $uom): ?>
                        <option value="<?php echo $uom; ?>" <?php echo ($uom == $product['unit_of_measure']) ? 'selected' : ''; ?>>
                            <?php echo $uom; ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="3"><?php echo htmlspecialchars($product['description'] ?? ''); ?></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Cost Price (Rs.) *</label>
                    <input type="number" name="cost_price" class="form-control" step="0.01" min="0" value="<?php echo $product['cost_price']; ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Selling Price (Rs.) *</label>
                    <input type="number" name="selling_price" class="form-control" step="0.01" min="0" value="<?php echo $product['selling_price']; ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Reorder Point</label>
                    <input type="number" name="reorder_point" class="form-control" step="0.01" min="0" value="<?php echo $product['reorder_point']; ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Safety Stock</label>
                    <input type="number" name="safety_stock" class="form-control" step="0.01" min="0" value="<?php echo $product['safety_stock']; ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-dark">
                <i class="bi bi-check-circle"></i> Changes Save Karo
            </button>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>