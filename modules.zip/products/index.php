<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';

$conn = getConnection();
$success = "";
$error = "";

// Status toggle (Activate/Deactivate)
if(isset($_GET['toggle'])) {
    $product_id = (int)$_GET['toggle'];
    
    $check = mysqli_prepare($conn, "SELECT status FROM products WHERE product_id = ?");
    mysqli_stmt_bind_param($check, "i", $product_id);
    mysqli_stmt_execute($check);
    $result = mysqli_stmt_get_result($check);
    
    if($row = mysqli_fetch_assoc($result)) {
        $new_status = ($row['status'] == 'ACTIVE') ? 'DISCONTINUED' : 'ACTIVE';
        
        $stmt = mysqli_prepare($conn, "UPDATE products SET status = ? WHERE product_id = ?");
        mysqli_stmt_bind_param($stmt, "si", $new_status, $product_id);
        
        if(mysqli_stmt_execute($stmt)) {
            $success = "Product status update ho gaya!";
        } else {
            $error = "Kuch galat hua!";
        }
    }
}

// Saare products lao (category ke naam ke saath)
$products = mysqli_query($conn, "SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id = c.category_id ORDER BY p.name");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-box-seam"></i> Products</h4>
    <div>
        <a href="categories.php" class="btn btn-outline-dark me-2">
            <i class="bi bi-tags"></i> Categories
        </a>
        <a href="add.php" class="btn btn-dark">
            <i class="bi bi-plus-circle"></i> Naya Product Add Karo
        </a>
    </div>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>SKU</th>
                    <th>Naam</th>
                    <th>Category</th>
                    <th>Unit</th>
                    <th>Cost Price</th>
                    <th>Selling Price</th>
                    <th>Reorder Point</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($products) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($products)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['sku']); ?> </td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo $row['category_name'] ?? '-'; ?></td>
                        <td><?php echo $row['unit_of_measure']; ?></td>
                        <td>Rs. <?php echo number_format($row['cost_price'], 2); ?></td>
                        <td>Rs. <?php echo number_format($row['selling_price'], 2); ?></td>
                        <td><?php echo $row['reorder_point']; ?></td>
                        <td>
                            <?php if($row['status'] == 'ACTIVE'): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Discontinued</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="edit.php?id=<?php echo $row['product_id']; ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <a href="?toggle=<?php echo $row['product_id']; ?>" 
                               class="btn btn-sm btn-outline-<?php echo $row['status'] == 'ACTIVE' ? 'secondary' : 'success'; ?>"
                               onclick="return confirm('Status change karna hai?')">
                                <?php echo $row['status'] == 'ACTIVE' ? 'Deactivate' : 'Activate'; ?>
                            </a>
                            <a href="barcode.php?id=<?php echo $row['product_id']; ?>" class="btn btn-sm btn-outline-dark" target="_blank"> <i class="bi bi-upc"></i> </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center text-muted">
                            Abhi koi product nahi hai. <a href="add.php">Pehla product add karo</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>