<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/audit.php';

$conn = getConnection();
$error = "";

if(!isset($_GET['id'])) {
    require_once '../../includes/header.php';
    header("Location: index.php");
    exit();
}

$so_id = (int)$_GET['id'];

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    csrf_verify();
    $action = $_POST['action'];
    $new_status = "";

    if($action == 'confirm') {
        $lines = mysqli_query($conn, "SELECT sl.product_id, sl.quantity_ordered, COALESCE(SUM(ii.quantity_on_hand),0) as stock FROM so_line_items sl LEFT JOIN inventory_items ii ON sl.product_id = ii.product_id WHERE sl.so_id = $so_id GROUP BY sl.product_id, sl.quantity_ordered");
        $ok = true;
        while($l = mysqli_fetch_assoc($lines)) {
            if($l['stock'] < $l['quantity_ordered']) $ok = false;
        }
        if($ok) {
            $new_status = 'CONFIRMED';
        } else {
            $error = "Kuch products ka stock kam hai, confirm nahi ho sakta!";
        }
    }
    if($action == 'picking') $new_status = 'PICKING';
    if($action == 'deliver') $new_status = 'DELIVERED';
    if($action == 'cancel') $new_status = 'CANCELLED';

    $manager_only = ['cancel']; 
    if(in_array($action, $manager_only) && !in_array($_SESSION['role'], ['ADMIN', 'MANAGER'])) { $error = "Sirf Manager ya Admin ye action kar sakte hain!"; }
    elseif($new_status) {
        $stmt = mysqli_prepare($conn, "UPDATE sales_orders SET status = ? WHERE so_id = ?");
        mysqli_stmt_bind_param($stmt, "si", $new_status, $so_id);
        mysqli_stmt_execute($stmt);
        logAudit($conn, $_SESSION['user_id'], 'sales_orders', $so_id, 'UPDATE', null, ['status' => $new_status]);
    }
}

require_once '../../includes/header.php';

$stmt = mysqli_prepare($conn, "SELECT so.*, u.full_name as created_by_name FROM sales_orders so JOIN users u ON so.created_by = u.user_id WHERE so.so_id = ?");
mysqli_stmt_bind_param($stmt, "i", $so_id);
mysqli_stmt_execute($stmt);
$so = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$so) {
    header("Location: index.php");
    exit();
}

$lines = mysqli_query($conn, "
    SELECT sl.*, p.name as product_name, p.sku
    FROM so_line_items sl
    JOIN products p ON sl.product_id = p.product_id
    WHERE sl.so_id = $so_id
");

mysqli_close($conn);

$badges = ['DRAFT' => 'secondary', 'CONFIRMED' => 'primary', 'PICKING' => 'info', 'DISPATCHED' => 'warning', 'DELIVERED' => 'success', 'CANCELLED' => 'danger'];
$badge = $badges[$so['status']] ?? 'secondary';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-file-text"></i> SO #<?php echo $so_id; ?> <span class="badge bg-<?php echo $badge; ?>"><?php echo $so['status']; ?></span></h4>
    <<span>
        <a href="invoice.php?id=<?php echo $so_id; ?>" class="btn btn-dark" target="_blank">
            <i class="bi bi-receipt"></i> Invoice
        </a>
        <?php if($so['payment_status'] != 'PAID'): ?> <a href="record_payment.php?id=<?php echo $so_id; ?>" class="btn btn-success me-2"> <i class="bi bi-cash-coin"></i> Payment Record Karo </a> <?php endif; ?>
        <a href="index.php" class="btn btn-outline-dark">
            <i class="bi bi-arrow-left"></i> Wapas Jao
        </a>
    </span>
</div>
<?php if($error): ?> <div class="alert alert-danger"><?php echo $error; ?></div> <?php endif; ?>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3"><strong>Customer:</strong><br><?phpecho htmlspecialchars($so['customer_name']); ?></div>
            <div class="col-md-3"><strong>Email/Phone:</strong><br><?php echo ($so['customer_email'] ?? '-') . ' / ' . ($so['customer_phone'] ?? '-'); ?></div>
            <div class="col-md-3"><strong>Total Amount:</strong><br>Rs. <?php echo number_format($so['total_amount'], 2); ?></div>
            <div class="col-md-3"><strong>Created By:</strong><br><?php echo $so['created_by_name']; ?></div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white"><h6 class="mb-0">Line Items</h6></div>
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>Product</th>
                    <th>Unit Price</th>
                    <th>Ordered</th>
                    <th>Fulfilled</th>
                    <th>Outstanding</th>
                </tr>
            </thead>
            <tbody>
                <?php while($line = mysqli_fetch_assoc($lines)): ?>
                <tr>
                    <td><?php echo $line['product_name'] . ' (' . $line['sku'] . ')'; ?></td>
                    <td>Rs. <?php echo number_format($line['unit_price'], 2); ?></td>
                    <td><?php echo $line['quantity_ordered']; ?></td>
                    <td><?php echo $line['quantity_fulfilled']; ?></td>
                    <td><?php echo $line['quantity_ordered'] - $line['quantity_fulfilled']; ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <?php if($so['status'] == 'DRAFT'): ?>
            <form method="POST" class="d-inline"><?php echo csrf_field(); ?><input type="hidden" name="action" value="confirm"><button class="btn btn-primary">Confirm Karo</button></form>
            <form method="POST" class="d-inline"><?php echo csrf_field(); ?><input type="hidden" name="action" value="cancel"><button class="btn btn-outline-danger" onclick="return confirm('Cancel karna hai?')">Cancel Karo</button></form>
        <?php elseif($so['status'] == 'CONFIRMED'): ?>
            <form method="POST" class="d-inline"><?php echo csrf_field(); ?><input type="hidden" name="action" value="picking"><button class="btn btn-info">Picking Shuru Karo</button></form>
            <form method="POST" class="d-inline"><?php echo csrf_field(); ?><input type="hidden" name="action" value="cancel"><button class="btn btn-outline-danger" onclick="return confirm('Cancel karna hai?')">Cancel Karo</button></form>
        <?php elseif($so['status'] == 'PICKING'): ?>
            <a href="dispatch.php?so_id=<?php echo $so_id; ?>" class="btn btn-warning">
                <i class="bi bi-truck"></i> Dispatch Karo
            </a>
        <?php elseif($so['status'] == 'DISPATCHED'): ?>
            <form method="POST" class="d-inline"><?php echo csrf_field(); ?><input type="hidden" name="action" value="deliver"><button class="btn btn-success">Delivered Mark Karo</button></form>
        <?php else: ?>
            <p class="text-muted mb-0">Is SO pe koi aur action possible nahi hai.</p>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>