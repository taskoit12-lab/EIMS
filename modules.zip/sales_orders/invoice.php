<?php
session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: " . BASE_URL . "login.php");
    exit();
}

if(!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$conn = getConnection();
$so_id = (int)$_GET['id'];

$stmt = mysqli_prepare($conn, "SELECT * FROM sales_orders WHERE so_id = ?");
mysqli_stmt_bind_param($stmt, "i", $so_id);
mysqli_stmt_execute($stmt);
$so = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$so) {
    header("Location: index.php");
    exit();
}

$lines = mysqli_query($conn, "
    SELECT sl.*, p.name as product_name, p.sku
    FROM so_line_items sl
    JOIN products p ON sl.product_id = p.product_id
    WHERE sl.so_id = $so_id
");

$company = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM company_settings WHERE id = 1"));

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Invoice #<?php echo $so_id; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 30px; }
        .invoice-header { border-bottom: 3px solid #2c3e50; padding-bottom: 20px; margin-bottom: 20px; }
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="no-print mb-3 text-end">
            <button onclick="window.print()" class="btn btn-dark"><i class="bi bi-printer"></i> Print Invoice</button>
            <a href="view.php?id=<?php echo $so_id; ?>" class="btn btn-outline-secondary">Wapas Jao</a>
        </div>

        <div class="invoice-header d-flex justify-content-between">
            <div>
                <h3><?php echo htmlspecialchars($company['business_name']); ?></h3>
                <p class="mb-0"><?php echo nl2br(htmlspecialchars($company['address'] ?? '')); ?></p>
                <p class="mb-0"><?php echo htmlspecialchars($company['phone'] ?? ''); ?> <?php echo $company['email'] ? '| ' . htmlspecialchars($company['email']) : ''; ?></p>
                <?php if(!empty($company['gstin'])): ?>
                <p class="mb-0">GSTIN: <?php echo htmlspecialchars($company['gstin']); ?></p>
                <?php endif; ?>
            </div>
            <div class="text-end">
                <h4>INVOICE</h4>
                <p class="mb-0">Invoice #: SO-<?php echo $so_id; ?></p>
                <p class="mb-0">Date: <?php echo date('d-M-Y', strtotime($so['order_date'])); ?></p>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-6">
                <h6>Bill To:</h6>
                <p class="mb-0"><strong><?php echo htmlspecialchars($so['customer_name']); ?></strong></p>
                <p class="mb-0"><?php echo htmlspecialchars($so['customer_phone'] ?? ''); ?></p>
                <p class="mb-0"><?php echo htmlspecialchars($so['customer_email'] ?? ''); ?></p>
            </div>
        </div>

        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Product</th>
                    <th>SKU</th>
                    <th class="text-end">Qty</th>
                    <th class="text-end">Unit Price</th>
                    <th class="text-end">Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; $grand_total = 0; while($line = mysqli_fetch_assoc($lines)): ?>
                <?php $amount = $line['quantity_ordered'] * $line['unit_price']; $grand_total += $amount; ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo htmlspecialchars($line['product_name']); ?></td>
                    <td><?php echo htmlspecialchars($line['sku']); ?></td>
                    <td class="text-end"><?php echo $line['quantity_ordered']; ?></td>
                    <td class="text-end">Rs. <?php echo number_format($line['unit_price'], 2); ?></td>
                    <td class="text-end">Rs. <?php echo number_format($amount, 2); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="5" class="text-end">Subtotal</th>
                    <th class="text-end">Rs. <?php echo number_format($grand_total, 2); ?></th>
                </tr>
                <?php if($so['discount_amount'] > 0): ?>
                <tr>
                    <th colspan="5" class="text-end">Discount</th>
                    <th class="text-end">- Rs. <?php echo number_format($so['discount_amount'], 2); ?></th>
                </tr>
                <?php endif; ?>
                <tr>
                    <th colspan="5" class="text-end">Grand Total</th>
                    <th class="text-end">Rs. <?php echo number_format($so['total_amount'], 2); ?></th>
                </tr>
            </tfoot>     
        </table>
        <div class="row mt-3">
            <div class="col-6">
                <p class="mb-0"><strong>Payment Method:</strong> <?php echo htmlspecialchars($so['payment_method']); ?></p>
                <p class="mb-0"><strong>Amount Paid:</strong> Rs. <?php echo number_format($so['amount_paid'], 2); ?></p>
                <?php if($so['payment_status'] != 'PAID'): ?>
                <p class="mb-0 text-danger"><strong>Balance Due:</strong> Rs. <?php echo number_format($so['total_amount'] - $so['amount_paid'], 2); ?></p>
                <?php endif; ?>
            </div>
            <?php if($so['payment_status'] != 'PAID' && !empty($company['upi_id'])): ?>
            <div class="col-6 text-center">
                <p class="mb-1"><strong>Scan to Pay</strong></p>
                <?php
                $balance_due = $so['total_amount'] - $so['amount_paid'];
                $upi_link = "upi://pay?pa=" . urlencode($company['upi_id']) . "&pn=" . urlencode($company['business_name']) . "&am=" . $balance_due . "&cu=INR&tn=" . urlencode("Invoice SO-" . $so_id);
                $qr_url = "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" . urlencode($upi_link);
                ?>
                <img src="<?php echo $qr_url; ?>" alt="UPI QR Code" width="110" height="110">
                <p class="small text-muted mb-0"><?php echo htmlspecialchars($company['upi_id']); ?></p>
            </div>
            <?php endif; ?>
        </div>
        <p class="text-muted mt-4 text-center">Thank you for your business!</p>
    </div>
</body>
</html>