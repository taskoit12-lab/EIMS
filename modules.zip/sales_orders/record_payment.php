<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/audit.php';

$conn = getConnection();
require_once '../../includes/auth.php';
requireRole(['ADMIN', 'MANAGER', 'STAFF']);
require_once '../../includes/csrf.php';

$error = "";

if(!isset($_GET['id'])) {
    require_once '../../includes/header.php';
    header("Location: index.php");
    exit();
}

$so_id = (int)$_GET['id'];

$stmt = mysqli_prepare($conn, "SELECT * FROM sales_orders WHERE so_id = ?");
mysqli_stmt_bind_param($stmt, "i", $so_id);
mysqli_stmt_execute($stmt);
$so = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$so) {
    require_once '../../includes/header.php';
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $amount = (float)$_POST['amount'];
    $payment_method = $_POST['payment_method'];
    $payment_date = $_POST['payment_date'];
    $notes = trim($_POST['notes']);
    $recorded_by = $_SESSION['user_id'];

    $balance_due = $so['total_amount'] - $so['amount_paid'];

    if($amount <= 0) {
        $error = "Amount 0 se zyada hona chahiye!";
    } elseif($amount > $balance_due) {
        $error = "Itni zyada payment nahi ho sakti! Sirf Rs. " . number_format($balance_due, 2) . " due hai.";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO payments (so_id, amount, payment_method, payment_date, recorded_by, notes) VALUES (?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "idssis", $so_id, $amount, $payment_method, $payment_date, $recorded_by, $notes);
        mysqli_stmt_execute($stmt);

        $new_amount_paid = $so['amount_paid'] + $amount;
        $new_status = ($new_amount_paid >= $so['total_amount']) ? 'PAID' : 'PARTIAL';

        $upd = mysqli_prepare($conn, "UPDATE sales_orders SET amount_paid = ?, payment_status = ? WHERE so_id = ?");
        mysqli_stmt_bind_param($upd, "dsi", $new_amount_paid, $new_status, $so_id);
        mysqli_stmt_execute($upd);

        logAudit($conn, $recorded_by, 'sales_orders', $so_id, 'UPDATE', null, ['payment_recorded' => $amount, 'new_status' => $new_status]);

        header("Location: view.php?id=" . $so_id);
        exit();
    }
}

require_once '../../includes/header.php';

$so_fresh = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM sales_orders WHERE so_id = $so_id"));
$balance_due = $so_fresh['total_amount'] - $so_fresh['amount_paid'];

$payment_history = mysqli_query($conn, "SELECT p.*, u.full_name FROM payments p JOIN users u ON p.recorded_by = u.user_id WHERE p.so_id = $so_id ORDER BY p.payment_date DESC");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-cash-coin"></i> Payment Record Karo — SO #<?php echo $so_id; ?></h4>
    <a href="view.php?id=<?php echo $so_id; ?>" class="btn btn-outline-dark"><i class="bi bi-arrow-left"></i> Wapas Jao</a>
</div>

<?php if($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

<div class="row mb-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <p class="text-muted mb-1">Total Amount</p>
                <h4>Rs. <?php echo number_format($so_fresh['total_amount'], 2); ?></h4>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <p class="text-muted mb-1">Already Paid</p>
                <h4 class="text-success">Rs. <?php echo number_format($so_fresh['amount_paid'], 2); ?></h4>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <p class="text-muted mb-1">Balance Due</p>
                <h4 class="text-danger">Rs. <?php echo number_format($balance_due, 2); ?></h4>
            </div>
        </div>
    </div>
</div>

<?php if($balance_due > 0): ?>
<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white"><h6 class="mb-0">Nayi Payment Record Karo</h6></div>
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label class="form-label">Amount (Rs.) *</label>
                    <input type="number" name="amount" class="form-control" step="0.01" min="0.01" max="<?php echo $balance_due; ?>" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Payment Method</label>
                    <select name="payment_method" class="form-select">
                        <option value="CASH">Cash</option>
                        <option value="UPI">UPI</option>
                        <option value="CARD">Card</option>
                    </select>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">Date</label>
                    <input type="date" name="payment_date" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
                <div class="col-md-3 mb-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-success w-100">Payment Record Karo</button>
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Notes</label>
                    <input type="text" name="notes" class="form-control" placeholder="Optional">
                </div>
            </div>
        </form>
    </div>
</div>
<?php else: ?>
<div class="alert alert-success">Ye order poora paid ho chuka hai. 🎉</div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white"><h6 class="mb-0">Payment History</h6></div>
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr><th>Date</th><th>Amount</th><th>Method</th><th>Recorded By</th><th>Notes</th></tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($payment_history) > 0): ?>
                    <?php while($p = mysqli_fetch_assoc($payment_history)): ?>
                    <tr>
                        <td><?php echo date('d-M-Y', strtotime($p['payment_date'])); ?></td>
                        <td>Rs. <?php echo number_format($p['amount'], 2); ?></td>
                        <td><?php echo htmlspecialchars($p['payment_method']); ?></td>
                        <td><?php echo htmlspecialchars($p['full_name']); ?></td>
                        <td><?php echo htmlspecialchars($p['notes'] ?? '-'); ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-center text-muted">Koi aur payment nahi hai abhi tak</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>