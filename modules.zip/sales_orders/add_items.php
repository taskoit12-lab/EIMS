<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/audit.php';

$conn = getConnection();
require_once '../../includes/auth.php'; 
requireRole(['ADMIN', 'MANAGER', 'STAFF']);
$error = "";

if(!isset($_GET['so_id'])) {
    require_once '../../includes/header.php';
    header("Location: index.php");
    exit();
}

$so_id = (int)$_GET['so_id'];

$stmt = mysqli_prepare($conn, "SELECT * FROM sales_orders WHERE so_id = ?");
mysqli_stmt_bind_param($stmt, "i", $so_id);
mysqli_stmt_execute($stmt);
$so = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$so) {
    require_once '../../includes/header.php';
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $quantities = $_POST['qty'] ?? [];
    $prices = $_POST['price'] ?? [];
    $total = 0;
    $added_any = false;

    foreach($quantities as $product_id => $qty) {
        $qty = (float)$qty;
        if($qty > 0) {
            $unit_price = (float)$prices[$product_id];
            $product_id = (int)$product_id;

            $stmt = mysqli_prepare($conn, "INSERT INTO so_line_items (so_id, product_id, quantity_ordered, unit_price) VALUES (?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "iidd", $so_id, $product_id, $qty, $unit_price);
            mysqli_stmt_execute($stmt);

            $total += $qty * $unit_price;
            $added_any = true;
        }
    }

    if($added_any) {
        $upd = mysqli_prepare($conn, "UPDATE sales_orders SET total_amount = ? WHERE so_id = ?");
        mysqli_stmt_bind_param($upd, "di", $total, $so_id);
        mysqli_stmt_execute($upd);

        logAudit($conn, $_SESSION['user_id'], 'sales_orders', $so_id, 'UPDATE', null, ['total_amount' => $total]);

        header("Location: view.php?id=" . $so_id);
        exit();
    } else {
        $error = "Kam se kam ek product ki quantity daalo!";
    }
}

require_once '../../includes/header.php';

$products = mysqli_query($conn, "
    SELECT p.product_id, p.name, p.sku, p.selling_price, COALESCE(SUM(ii.quantity_on_hand), 0) as total_stock
    FROM products p
    LEFT JOIN inventory_items ii ON p.product_id = ii.product_id
    WHERE p.status = 'ACTIVE'
    GROUP BY p.product_id
    ORDER BY p.name
");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-list-check"></i> SO #<?php echo $so_id; ?> — Products Add Karo</h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <?php if(mysqli_num_rows($products) > 0): ?>
        <form method="POST">
            <?php echo csrf_field(); ?>
            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Product</th>
                        <th>Available Stock</th>
                        <th>Unit Price (Rs.)</th>
                        <th>Quantity Order Karni Hai</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($item = mysqli_fetch_assoc($products)): ?>
                    <tr>
                        <td><?php echo $item['name'] . ' (' . $item['sku'] . ')'; ?></td>
                        <td>
                            <?php if($item['total_stock'] <= 0): ?>
                                <span class="badge bg-danger">Out of Stock</span>
                            <?php else: ?>
                                <?php echo $item['total_stock']; ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <input type="number" name="price[<?php echo $item['product_id']; ?>]" class="form-control" value="<?php echo $item['selling_price']; ?>" step="0.01" min="0">
                        </td>
                        <td>
                            <input type="number" name="qty[<?php echo $item['product_id']; ?>]" class="form-control" value="0" step="0.01" min="0">
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <button type="submit" class="btn btn-dark">
                <i class="bi bi-check-circle"></i> SO Finalize Karo
            </button>
        </form>
        <?php else: ?>
            <p class="text-muted">Koi active product nahi hai.</p>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>