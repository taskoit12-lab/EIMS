<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';

$conn = getConnection();

$orders = mysqli_query($conn, "SELECT * FROM sales_orders ORDER BY created_at DESC");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-cart-dash"></i> Sales Orders</h4>
    <a href="add.php" class="btn btn-dark">
        <i class="bi bi-plus-circle"></i> Naya SO Banao
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>SO #</th>
                    <th>Customer</th>
                    <th>Order Date</th>
                    <th>Total Amount</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($orders) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($orders)): ?>
                    <tr>
                        <td>#<?php echo $row['so_id']; ?></td>
                        <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                        <td><?php echo date('d-M-Y', strtotime($row['order_date'])); ?></td>
                        <td>Rs. <?php echo number_format($row['total_amount'], 2); ?></td>
                        <td>
                            <?php
                            $badges = ['DRAFT' => 'secondary', 'CONFIRMED' => 'primary', 'PICKING' => 'info', 'DISPATCHED' => 'warning', 'DELIVERED' => 'success', 'CANCELLED' => 'danger'];
                            $badge = $badges[$row['status']] ?? 'secondary';
                            ?>
                            <span class="badge bg-<?php echo $badge; ?>"><?php echo $row['status']; ?></span>
                        </td>
                        <td>
                            <a href="view.php?id=<?php echo $row['so_id']; ?>" class="btn btn-sm btn-outline-dark">
                                <i class="bi bi-eye"></i> View
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted">
                            Abhi koi sales order nahi hai. <a href="add.php">Pehla SO banao</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>