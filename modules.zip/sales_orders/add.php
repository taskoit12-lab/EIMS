<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/audit.php';

$conn = getConnection();
require_once '../../includes/auth.php'; 
requireRole(['ADMIN', 'MANAGER', 'STAFF']);
$error = "";

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $customer_name = trim($_POST['customer_name']);
    $customer_email = trim($_POST['customer_email']);
    $customer_phone = trim($_POST['customer_phone']);
    $order_reference = trim($_POST['order_reference']);
    $created_by = $_SESSION['user_id'];

    if(empty($customer_name)) {
        $error = "Customer naam zaroori hai!";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO sales_orders (customer_name, customer_email, customer_phone, order_reference, status, order_date, created_by) VALUES (?, ?, ?, ?, 'DRAFT', CURDATE(), ?)");
        mysqli_stmt_bind_param($stmt, "ssssi", $customer_name, $customer_email, $customer_phone, $order_reference, $created_by);

        if(mysqli_stmt_execute($stmt)) {
            $new_so_id = mysqli_insert_id($conn);
            logAudit($conn, $created_by, 'sales_orders', $new_so_id, 'CREATE', null, ['customer_name' => $customer_name]);
            header("Location: add_items.php?so_id=" . $new_so_id);
            exit();
        } else {
            $error = "Kuch galat hua: " . mysqli_error($conn);
        }
    }
}

require_once '../../includes/header.php';
mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-cart-dash"></i> Naya Sales Order — Step 1</h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Customer Naam *</label>
                    <input type="text" name="customer_name" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Order Reference</label>
                    <input type="text" name="order_reference" class="form-control" placeholder="Optional PO number etc.">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="customer_email" class="form-control">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Phone</label>
                    <input type="text" name="customer_phone" class="form-control">
                </div>
            </div>
            <button type="submit" class="btn btn-dark">
                <i class="bi bi-arrow-right-circle"></i> Aage Badho — Products Add Karo
            </button>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>