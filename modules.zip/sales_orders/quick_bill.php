<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/audit.php';

$conn = getConnection();
require_once '../../includes/auth.php';
requireRole(['ADMIN', 'MANAGER', 'STAFF']);

$error = "";

if(!isset($_SESSION['quick_cart'])) {
    $_SESSION['quick_cart'] = [];
}

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_item'])) {
    csrf_verify();
    $sku = trim($_POST['scan_sku']);
    $stmt = mysqli_prepare($conn, "SELECT product_id, name, sku, selling_price FROM products WHERE sku = ? AND status='ACTIVE'");
    mysqli_stmt_bind_param($stmt, "s", $sku);
    mysqli_stmt_execute($stmt);
    $product = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if($product) {
        $pid = $product['product_id'];
        if(isset($_SESSION['quick_cart'][$pid])) {
            $_SESSION['quick_cart'][$pid]['qty'] += 1;
        } else {
            $_SESSION['quick_cart'][$pid] = [
                'name' => $product['name'],
                'sku' => $product['sku'],
                'price' => $product['selling_price'],
                'qty' => 1
            ];
        }
    } else {
        $error = "SKU '$sku' wala product nahi mila!";
    }
}

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_qty'])) {
    csrf_verify();
    $pid = (int)$_POST['product_id'];
    $new_qty = (float)$_POST['new_qty'];
    if($new_qty > 0) {
        $_SESSION['quick_cart'][$pid]['qty'] = $new_qty;
    } else {
        unset($_SESSION['quick_cart'][$pid]);
    }
}

if(isset($_GET['remove'])) {
    unset($_SESSION['quick_cart'][(int)$_GET['remove']]);
}

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['checkout'])) {
    csrf_verify();
    $customer_name = trim($_POST['customer_name']) ?: 'Walk-in Customer';
    $location_id = (int)$_POST['location_id'];
    $performed_by = $_SESSION['user_id'];

    if(empty($_SESSION['quick_cart'])) {
        $error = "Cart khaali hai!";
    } elseif(empty($location_id)) {
        $error = "Location select karna zaroori hai!";
    } else {
        $total = 0;
        foreach($_SESSION['quick_cart'] as $item) {
            $total += $item['qty'] * $item['price'];
        }

        $discount_amount = (float)($_POST['discount_amount'] ?? 0);
        $payment_method = $_POST['payment_method'] ?? 'CASH';
        $final_total = $total - $discount_amount;
        $amount_paid = (float)($_POST['amount_paid'] ?? $final_total);

        if($amount_paid >= $final_total) {
            $payment_status = 'PAID';
        } elseif($amount_paid > 0) {
            $payment_status = 'PARTIAL';
        } else {
            $payment_status = 'DUE';
        }

        $stmt = mysqli_prepare($conn, "INSERT INTO sales_orders (customer_name, status, order_date, dispatch_date, total_amount, discount_amount, payment_method, amount_paid, payment_status, created_by) VALUES (?, 'DELIVERED', CURDATE(), CURDATE(), ?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sddsdsi", $customer_name, $final_total, $discount_amount, $payment_method, $amount_paid, $payment_status, $performed_by);
        mysqli_stmt_execute($stmt);
        $new_so_id = mysqli_insert_id($conn);

        foreach($_SESSION['quick_cart'] as $pid => $item) {
            $qty = $item['qty'];
            $price = $item['price'];

            $stmt = mysqli_prepare($conn, "INSERT INTO so_line_items (so_id, product_id, quantity_ordered, quantity_fulfilled, unit_price) VALUES (?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "iiddd", $new_so_id, $pid, $qty, $qty, $price);
            mysqli_stmt_execute($stmt);

            $check = mysqli_prepare($conn, "SELECT item_id, quantity_on_hand FROM inventory_items WHERE product_id = ? AND location_id = ?");
            mysqli_stmt_bind_param($check, "ii", $pid, $location_id);
            mysqli_stmt_execute($check);
            $existing = mysqli_fetch_assoc(mysqli_stmt_get_result($check));
            $qty_before = $existing ? $existing['quantity_on_hand'] : 0;
            $qty_after = $qty_before - $qty;

            if($existing) {
                $upd = mysqli_prepare($conn, "UPDATE inventory_items SET quantity_on_hand = ? WHERE item_id = ?");
                mysqli_stmt_bind_param($upd, "di", $qty_after, $existing['item_id']);
                mysqli_stmt_execute($upd);
            }

            $mov = mysqli_prepare($conn, "INSERT INTO movement_records (product_id, from_location_id, to_location_id, movement_type, quantity, qty_before, qty_after, reference_type, reference_id, performed_by) VALUES (?, ?, NULL, 'ISSUE', ?, ?, ?, 'SO', ?, ?)");
            mysqli_stmt_bind_param($mov, "iidddii", $pid, $location_id, $qty, $qty_before, $qty_after, $new_so_id, $performed_by);
            mysqli_stmt_execute($mov);
        }

        logAudit($conn, $performed_by, 'sales_orders', $new_so_id, 'CREATE', null, ['type' => 'QUICK_BILL', 'total' => $final_total, 'payment_status' => $payment_status]);

        $_SESSION['quick_cart'] = [];
        header("Location: invoice.php?id=" . $new_so_id);
        exit();
    }
}

require_once '../../includes/header.php';

$locations = mysqli_query($conn, "SELECT l.location_id, w.name as wname, l.zone_code, l.bin_code FROM locations l JOIN warehouses w ON l.warehouse_id = w.warehouse_id");
$locations_arr = mysqli_fetch_all($locations, MYSQLI_ASSOC);

mysqli_close($conn);

$grand_total = 0;
foreach($_SESSION['quick_cart'] as $item) {
    $grand_total += $item['qty'] * $item['price'];
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-upc-scan"></i> Quick Billing</h4>
    <a href="index.php" class="btn btn-outline-dark"><i class="bi bi-arrow-left"></i> Wapas Jao</a>
</div>

<?php if($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <label class="form-label">Scan Barcode ya SKU Type Karo</label>
            <div class="input-group">
                <input type="text" name="scan_sku" class="form-control form-control-lg" autofocus placeholder="Jaise: DELL-LAP-001" required>
                <button type="submit" name="add_item" class="btn btn-dark">Add</button>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr><th>Product</th><th>SKU</th><th>Price</th><th>Qty</th><th>Subtotal</th><th>Action</th></tr>
            </thead>
            <tbody>
                <?php if(!empty($_SESSION['quick_cart'])): ?>
                    <?php foreach($_SESSION['quick_cart'] as $pid => $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                        <td><?php echo htmlspecialchars($item['sku']); ?></td>
                        <td>Rs. <?php echo number_format($item['price'], 2); ?></td>
                        <td>
                            <form method="POST" class="d-flex">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo $pid; ?>">
                                <input type="number" name="new_qty" value="<?php echo $item['qty']; ?>" class="form-control form-control-sm" style="width:70px" step="0.01" min="0">
                                <button type="submit" name="update_qty" class="btn btn-sm btn-outline-dark ms-1">Update</button>
                            </form>
                        </td>
                        <td>Rs. <?php echo number_format($item['qty'] * $item['price'], 2); ?></td>
                        <td><a href="?remove=<?php echo $pid; ?>" class="btn btn-sm btn-outline-danger">Remove</a></td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="text-center text-muted">Cart khaali hai — SKU scan karo shuru karne ke liye</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
        <h5 class="text-end">Cart Total: Rs. <?php echo number_format($grand_total, 2); ?></h5>
    </div>
</div>

<?php if(!empty($_SESSION['quick_cart'])): ?>
<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label">Customer Naam (optional)</label>
                    <input type="text" name="customer_name" class="form-control" placeholder="Walk-in Customer">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Location (kahan se nikalna hai) *</label>
                    <select name="location_id" class="form-select" required>
                        <option value="">-- Select Karo --</option>
                        <?php foreach($locations_arr as $l): ?>
                        <option value="<?php echo $l['location_id']; ?>"><?php echo htmlspecialchars($l['wname'] . ' - ' . ($l['zone_code'] ?? '') . '/' . ($l['bin_code'] ?? '')); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Discount (Rs.)</label>
                    <input type="number" name="discount_amount" class="form-control" value="0" step="0.01" min="0">
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Payment Method</label>
                    <select name="payment_method" class="form-select">
                        <option value="CASH">Cash</option>
                        <option value="UPI">UPI</option>
                        <option value="CARD">Card</option>
                        <option value="CREDIT">Credit (Baad mein milega)</option>
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Amount Paid (Rs.)</label>
                    <input type="number" name="amount_paid" class="form-control" value="<?php echo $grand_total; ?>" step="0.01" min="0">
                    <small class="text-muted">Credit ke liye 0 ya jitna abhi mila utna daalo</small>
                </div>
                <div class="col-md-4 mb-3 d-flex align-items-end">
                    <button type="submit" name="checkout" class="btn btn-success w-100">
                        <i class="bi bi-check-circle"></i> Sale Complete Karo
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<?php require_once '../../includes/footer.php'; ?>