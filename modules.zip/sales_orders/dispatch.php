<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/audit.php';

$conn = getConnection();
require_once '../../includes/auth.php'; 
requireRole(['ADMIN', 'MANAGER', 'STAFF']);
$error = "";

if(!isset($_GET['so_id'])) {
    require_once '../../includes/header.php';
    header("Location: index.php");
    exit();
}

$so_id = (int)$_GET['so_id'];

$stmt = mysqli_prepare($conn, "SELECT * FROM sales_orders WHERE so_id = ?");
mysqli_stmt_bind_param($stmt, "i", $so_id);
mysqli_stmt_execute($stmt);
$so = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$so) {
    require_once '../../includes/header.php';
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $dispatch_qty = $_POST['dispatch'] ?? [];
    $location_id = (int)$_POST['location_id'];
    $performed_by = $_SESSION['user_id'];
    $any_dispatched = false;

    foreach($dispatch_qty as $so_line_id => $qty) {
        $qty = (float)$qty;
        if($qty > 0) {
            $so_line_id = (int)$so_line_id;

            $line = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM so_line_items WHERE so_line_id = $so_line_id"));
            $outstanding = $line['quantity_ordered'] - $line['quantity_fulfilled'];

            if($qty > $outstanding) {
                $error = "Outstanding se zyada dispatch nahi kar sakte!";
                break;
            }

            $product_id = $line['product_id'];

            $check = mysqli_prepare($conn, "SELECT item_id, quantity_on_hand FROM inventory_items WHERE product_id = ? AND location_id = ?");
            mysqli_stmt_bind_param($check, "ii", $product_id, $location_id);
            mysqli_stmt_execute($check);
            $existing = mysqli_fetch_assoc(mysqli_stmt_get_result($check));

            $qty_before = $existing ? $existing['quantity_on_hand'] : 0;

            if($qty_before < $qty) {
                $error = "Is location mein itna stock available nahi hai!";
                break;
            }

            $qty_after = $qty_before - $qty;

            $upd = mysqli_prepare($conn, "UPDATE inventory_items SET quantity_on_hand = ? WHERE item_id = ?");
            mysqli_stmt_bind_param($upd, "di", $qty_after, $existing['item_id']);
            mysqli_stmt_execute($upd);

            $mov = mysqli_prepare($conn, "INSERT INTO movement_records (product_id, from_location_id, to_location_id, movement_type, quantity, qty_before, qty_after, reference_type, reference_id, performed_by) VALUES (?, ?, NULL, 'ISSUE', ?, ?, ?, 'SO', ?, ?)");
            mysqli_stmt_bind_param($mov, "iidddii", $product_id, $location_id, $qty, $qty_before, $qty_after, $so_id, $performed_by);
            mysqli_stmt_execute($mov);

            $new_fulfilled = $line['quantity_fulfilled'] + $qty;
            $updline = mysqli_prepare($conn, "UPDATE so_line_items SET quantity_fulfilled = ? WHERE so_line_id = ?");
            mysqli_stmt_bind_param($updline, "di", $new_fulfilled, $so_line_id);
            mysqli_stmt_execute($updline);

            // Reorder check
            $prod_check = mysqli_prepare($conn, "SELECT reorder_point FROM products WHERE product_id = ?");
            mysqli_stmt_bind_param($prod_check, "i", $product_id);
            mysqli_stmt_execute($prod_check);
            $prow = mysqli_fetch_assoc(mysqli_stmt_get_result($prod_check));

            if($qty_after <= $prow['reorder_point']) {
                $ac = mysqli_prepare($conn, "SELECT alert_id FROM reorder_alerts WHERE product_id=? AND location_id=? AND alert_status='ACTIVE'");
                mysqli_stmt_bind_param($ac, "ii", $product_id, $location_id);
                mysqli_stmt_execute($ac);
                mysqli_stmt_store_result($ac);
                if(mysqli_stmt_num_rows($ac) == 0) {
                    $ai = mysqli_prepare($conn, "INSERT INTO reorder_alerts (product_id, location_id, current_qty, reorder_point) VALUES (?, ?, ?, ?)");
                    mysqli_stmt_bind_param($ai, "iidd", $product_id, $location_id, $qty_after, $prow['reorder_point']);
                    mysqli_stmt_execute($ai);
                }
            }

            $any_dispatched = true;
        }
    }

    if($any_dispatched && !$error) {
        $stmt2 = mysqli_prepare($conn, "UPDATE sales_orders SET status = 'DISPATCHED', dispatch_date = CURDATE() WHERE so_id = ?");
        mysqli_stmt_bind_param($stmt2, "i", $so_id);
        mysqli_stmt_execute($stmt2);

        logAudit($conn, $performed_by, 'sales_orders', $so_id, 'UPDATE', null, ['status' => 'DISPATCHED']);

        header("Location: view.php?id=" . $so_id);
        exit();
    }
}

require_once '../../includes/header.php';

$lines = mysqli_query($conn, "
    SELECT sl.*, p.name as product_name, p.sku
    FROM so_line_items sl
    JOIN products p ON sl.product_id = p.product_id
    WHERE sl.so_id = $so_id AND sl.quantity_fulfilled < sl.quantity_ordered
");

$locations = mysqli_query($conn, "SELECT l.location_id, w.name as wname, l.zone_code, l.bin_code FROM locations l JOIN warehouses w ON l.warehouse_id = w.warehouse_id");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-truck"></i> Dispatch Karo — SO #<?php echo $so_id; ?></h4>
    <a href="view.php?id=<?php echo $so_id; ?>" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label">Kis location se nikalna hai *</label>
                <select name="location_id" class="form-select" required>
                    <option value="">-- Location Select Karo --</option>
                    <?php while($l = mysqli_fetch_assoc($locations)): ?>
                    <option value="<?php echo $l['location_id']; ?>"><?php echo $l['wname'] . ' - ' . ($l['zone_code'] ?? '') . '/' . ($l['bin_code'] ?? ''); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Product</th>
                        <th>Ordered</th>
                        <th>Already Dispatched</th>
                        <th>Outstanding</th>
                        <th>Ab Kitna Dispatch Karna Hai</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(mysqli_num_rows($lines) > 0): ?>
                        <?php while($line = mysqli_fetch_assoc($lines)): ?>
                        <?php $outstanding = $line['quantity_ordered'] - $line['quantity_fulfilled']; ?>
                        <tr>
                            <td><?php echo $line['product_name'] . ' (' . $line['sku'] . ')'; ?></td>
                            <td><?php echo $line['quantity_ordered']; ?></td>
                            <td><?php echo $line['quantity_fulfilled']; ?></td>
                            <td><?php echo $outstanding; ?></td>
                            <td>
                                <input type="number" name="dispatch[<?php echo $line['so_line_id']; ?>]" class="form-control" value="0" step="0.01" min="0" max="<?php echo $outstanding; ?>">
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center text-muted">Sab products already dispatch ho chuke hain</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <button type="submit" class="btn btn-warning">
                <i class="bi bi-check-circle"></i> Dispatch Confirm Karo
            </button>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>