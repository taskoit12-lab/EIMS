<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';

$conn = getConnection();

$rows = mysqli_query($conn, "
    SELECT p.name, p.sku, SUM(ii.quantity_on_hand) as total_qty,
           p.cost_price, p.selling_price,
           SUM(ii.quantity_on_hand) * p.cost_price as cost_value,
           SUM(ii.quantity_on_hand) * p.selling_price as selling_value
    FROM products p
    JOIN inventory_items ii ON p.product_id = ii.product_id
    GROUP BY p.product_id
    HAVING total_qty > 0
    ORDER BY cost_value DESC
");

$totals = mysqli_query($conn, "
    SELECT SUM(ii.quantity_on_hand * p.cost_price) as total_cost, SUM(ii.quantity_on_hand * p.selling_price) as total_selling
    FROM products p JOIN inventory_items ii ON p.product_id = ii.product_id
");
$t = mysqli_fetch_assoc($totals);

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-currency-rupee"></i> Stock Valuation Report</h4>
    <a href="index.php" class="btn btn-outline-dark"><i class="bi bi-arrow-left"></i> Wapas Jao</a>
</div>

<div class="row mb-4">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <p class="text-muted mb-1">Total Cost Value</p>
                <h3>Rs. <?php echo number_format($t['total_cost'] ?? 0, 2); ?></h3>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <p class="text-muted mb-1">Total Selling Value</p>
                <h3>Rs. <?php echo number_format($t['total_selling'] ?? 0, 2); ?></h3>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>Product</th>
                    <th>Total Qty</th>
                    <th>Cost Price</th>
                    <th>Cost Value</th>
                    <th>Selling Value</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($rows) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($rows)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['name'] . ' (' . $row['sku'] . ')'); ?></td>
                        <td><?php echo $row['total_qty']; ?></td>
                        <td>Rs. <?php echo number_format($row['cost_price'], 2); ?></td>
                        <td>Rs. <?php echo number_format($row['cost_value'], 2); ?></td>
                        <td>Rs. <?php echo number_format($row['selling_value'], 2); ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="5" class="text-center text-muted">Koi stock nahi hai</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>