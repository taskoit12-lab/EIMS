<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';
mysqli_close(getConnection());
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-file-earmark-bar-graph"></i> Reports</h4>
</div>

<div class="row g-3">
    <div class="col-md-4">
        <a href="stock_valuation.php" class="text-decoration-none">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <i class="bi bi-currency-rupee fs-3 text-primary"></i>
                    <h6 class="mt-2">Stock Valuation</h6>
                    <p class="text-muted small mb-0">Total stock value (cost & selling price)</p>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="low_stock.php" class="text-decoration-none">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <i class="bi bi-exclamation-triangle fs-3 text-danger"></i>
                    <h6 class="mt-2">Low Stock Alert Report</h6>
                    <p class="text-muted small mb-0">Products below reorder point</p>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="movement_history.php" class="text-decoration-none">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <i class="bi bi-clock-history fs-3 text-info"></i>
                    <h6 class="mt-2">Movement History</h6>
                    <p class="text-muted small mb-0">Complete stock movement log</p>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="po_status.php" class="text-decoration-none">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <i class="bi bi-cart-plus fs-3 text-warning"></i>
                    <h6 class="mt-2">PO Status Report</h6>
                    <p class="text-muted small mb-0">All purchase orders by status</p>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="so_summary.php" class="text-decoration-none">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <i class="bi bi-cart-dash fs-3 text-success"></i>
                    <h6 class="mt-2">Sales Order Summary</h6>
                    <p class="text-muted small mb-0">Revenue and order stats</p>
                </div>
            </div>
        </a>
    </div>
    <div class="col-md-4">
        <a href="returns_report.php" class="text-decoration-none">
            <div class="card border-0 shadow-sm h-100">
                <div class="card-body">
                    <i class="bi bi-arrow-return-left fs-3 text-secondary"></i>
                    <h6 class="mt-2">Returns Report</h6>
                    <p class="text-muted small mb-0">RMA summary by reason & disposition</p>
                </div>
            </div>
        </a>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>