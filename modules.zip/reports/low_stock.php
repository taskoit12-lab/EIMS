<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';

$conn = getConnection();

$rows = mysqli_query($conn, "
    SELECT ra.*, p.name as product_name, p.sku, w.name as warehouse_name, l.zone_code, l.bin_code
    FROM reorder_alerts ra
    JOIN products p ON ra.product_id = p.product_id
    JOIN locations l ON ra.location_id = l.location_id
    JOIN warehouses w ON l.warehouse_id = w.warehouse_id
    WHERE ra.alert_status = 'ACTIVE'
    ORDER BY ra.current_qty ASC
");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-exclamation-triangle text-danger"></i> Low Stock Alert Report</h4>
    <a href="index.php" class="btn btn-outline-dark"><i class="bi bi-arrow-left"></i> Wapas Jao</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>Product</th>
                    <th>Warehouse</th>
                    <th>Location</th>
                    <th>Current Qty</th>
                    <th>Reorder Point</th>
                    <th>Shortfall</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($rows) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($rows)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['product_name'] . ' (' . $row['sku'] . ')'); ?></td>
                        <td><?php echo $row['warehouse_name']; ?></td>
                        <td><?php echo ($row['zone_code'] ?? '-') . '/' . ($row['bin_code'] ?? '-'); ?></td>
                        <td class="text-danger fw-bold"><?php echo $row['current_qty']; ?></td>
                        <td><?php echo $row['reorder_point']; ?></td>
                        <td><?php echo $row['reorder_point'] - $row['current_qty']; ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="text-center text-muted">Koi low stock alert nahi hai — sab theek hai! 🎉</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>