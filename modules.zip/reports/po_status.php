<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';

$conn = getConnection();

$summary = mysqli_query($conn, "SELECT status, COUNT(*) as cnt, SUM(total_amount) as total FROM purchase_orders GROUP BY status");

$rows = mysqli_query($conn, "
    SELECT po.*, s.name as supplier_name, w.name as warehouse_name
    FROM purchase_orders po
    JOIN suppliers s ON po.supplier_id = s.supplier_id
    JOIN warehouses w ON po.warehouse_id = w.warehouse_id
    ORDER BY po.created_at DESC
");

mysqli_close($conn);

$badges = ['DRAFT' => 'secondary', 'SENT' => 'info', 'CONFIRMED' => 'primary', 'PARTIALLY_RECEIVED' => 'warning', 'RECEIVED' => 'success', 'CLOSED' => 'dark', 'CANCELLED' => 'danger'];
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-cart-plus"></i> Purchase Order Status Report</h4>
    <a href="index.php" class="btn btn-outline-dark"><i class="bi bi-arrow-left"></i> Wapas Jao</a>
</div>

<div class="row mb-4">
    <?php mysqli_data_seek($summary, 0); while($s = mysqli_fetch_assoc($summary)): ?>
    <div class="col-md-3 mb-2">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <span class="badge bg-<?php echo $badges[$s['status']] ?? 'secondary'; ?>"><?php echo $s['status']; ?></span>
                <h4 class="mt-2 mb-0"><?php echo $s['cnt']; ?></h4>
                <small class="text-muted">Rs. <?php echo number_format($s['total'], 2); ?></small>
            </div>
        </div>
    </div>
    <?php endwhile; ?>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr><th>PO #</th><th>Supplier</th><th>Warehouse</th><th>Amount</th><th>Status</th><th>Created</th></tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($rows)): ?>
                <tr>
                    <td>#<?php echo $row['po_id']; ?></td>
                    <td><?phpecho htmlspecialchars($row['supplier_name']); ?></td>
                    <td><?php echo $row['warehouse_name']; ?></td>
                    <td>Rs. <?php echo number_format($row['total_amount'], 2); ?></td>
                    <td><span class="badge bg-<?php echo $badges[$row['status']] ?? 'secondary'; ?>"><?php echo $row['status']; ?></span></td>
                    <td><?php echo date('d-M-Y', strtotime($row['created_at'])); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>