<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';

$conn = getConnection();

$by_reason = mysqli_query($conn, "SELECT reason_code, COUNT(*) as cnt FROM rma_records GROUP BY reason_code");
$by_disposition = mysqli_query($conn, "SELECT disposition, COUNT(*) as cnt FROM rma_records WHERE disposition IS NOT NULL GROUP BY disposition");

$rows = mysqli_query($conn, "
    SELECT r.*, p.name as product_name, p.sku, so.customer_name
    FROM rma_records r
    JOIN products p ON r.product_id = p.product_id
    JOIN sales_orders so ON r.so_id = so.so_id
    ORDER BY r.created_at DESC
");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-arrow-return-left"></i> Returns Report</h4>
    <a href="index.php" class="btn btn-outline-dark"><i class="bi bi-arrow-left"></i> Wapas Jao</a>
</div>

<div class="row mb-4">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white"><h6 class="mb-0">By Reason</h6></div>
            <div class="card-body">
                <?php if(mysqli_num_rows($by_reason) > 0): ?>
                    <?php while($r = mysqli_fetch_assoc($by_reason)): ?>
                    <div class="d-flex justify-content-between mb-2">
                        <span><?php echo $r['reason_code']; ?></span>
                        <span class="badge bg-secondary"><?php echo $r['cnt']; ?></span>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="text-muted mb-0">Koi data nahi hai</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white"><h6 class="mb-0">By Disposition</h6></div>
            <div class="card-body">
                <?php if(mysqli_num_rows($by_disposition) > 0): ?>
                    <?php while($d = mysqli_fetch_assoc($by_disposition)): ?>
                    <div class="d-flex justify-content-between mb-2">
                        <span><?php echo $d['disposition']; ?></span>
                        <span class="badge bg-secondary"><?php echo $d['cnt']; ?></span>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p class="text-muted mb-0">Koi inspected returns nahi hain</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr><th>RMA #</th><th>Customer</th><th>Product</th><th>Qty</th><th>Reason</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($rows) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($rows)): ?>
                    <tr>
                        <td>#<?php echo $row['rma_id']; ?></td>
                        <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['product_name'] . ' (' . $row['sku'] . ')'); ?></td>
                        <td><?php echo $row['quantity_returned']; ?></td>
                        <td><?php echo $row['reason_code']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="text-center text-muted">Koi returns nahi hain</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>