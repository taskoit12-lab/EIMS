<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';

$conn = getConnection();

$rows = mysqli_query($conn, "
    SELECT m.*, p.name as product_name, p.sku, u.full_name as user_name
    FROM movement_records m
    JOIN products p ON m.product_id = p.product_id
    JOIN users u ON m.performed_by = u.user_id
    ORDER BY m.occurred_at DESC
    LIMIT 200
");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-clock-history"></i> Movement History</h4>
    <a href="index.php" class="btn btn-outline-dark"><i class="bi bi-arrow-left"></i> Wapas Jao</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table class="table table-hover table-sm">
            <thead class="table-light">
                <tr>
                    <th>Product</th>
                    <th>Type</th>
                    <th>Qty</th>
                    <th>Before</th>
                    <th>After</th>
                    <th>Reference</th>
                    <th>By</th>
                    <th>Time</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($rows) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($rows)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['product_name'] . ' (' . $row['sku'] . ')'); ?></td>
                        <td>
                            <?php
                            $badges = ['RECEIPT' => 'success', 'ISSUE' => 'danger', 'TRANSFER' => 'info', 'ADJUSTMENT' => 'warning', 'RESTOCK' => 'primary'];
                            $badge = $badges[$row['movement_type']] ?? 'secondary';
                            ?>
                            <span class="badge bg-<?php echo $badge; ?>"><?php echo $row['movement_type']; ?></span>
                        </td>
                        <td><?php echo $row['quantity']; ?></td>
                        <td><?php echo $row['qty_before']; ?></td>
                        <td><?php echo $row['qty_after']; ?></td>
                        <td><?php echo $row['reference_type'] ? $row['reference_type'] . ' #' . $row['reference_id'] : '-'; ?></td>
                        <td><?php echo $row['user_name']; ?></td>
                        <td><?php echo date('d-M H:i', strtotime($row['occurred_at'])); ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="8" class="text-center text-muted">Koi movement nahi hai</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>