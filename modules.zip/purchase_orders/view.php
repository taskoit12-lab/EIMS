<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/audit.php';

$conn = getConnection();
$error = "";

if(!isset($_GET['id'])) {
    require_once '../../includes/header.php';
    header("Location: index.php");
    exit();
}

$po_id = (int)$_GET['id'];

// Status change actions
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    csrf_verify();
    $action = $_POST['action'];
    $new_status = "";

    if($action == 'send') $new_status = 'SENT';
    if($action == 'confirm') $new_status = 'CONFIRMED';
    if($action == 'close') $new_status = 'CLOSED';
    if($action == 'cancel') $new_status = 'CANCELLED';

    $manager_only = ['confirm', 'cancel'];
    if(in_array($action, $manager_only) && !in_array($_SESSION['role'], ['ADMIN', 'MANAGER'])) {
    $error = "Sirf Manager ya Admin ye action kar sakte hain!";
    } elseif($new_status) {
        $extra = ($action == 'confirm') ? ", approved_by = {$_SESSION['user_id']}" : "";
        $stmt = mysqli_prepare($conn, "UPDATE purchase_orders SET status = ?" . $extra . " WHERE po_id = ?");
        mysqli_stmt_bind_param($stmt, "si", $new_status, $po_id);
        mysqli_stmt_execute($stmt);
        logAudit($conn, $_SESSION['user_id'], 'purchase_orders', $po_id, 'UPDATE', null, ['status' => $new_status]);
    }
}

require_once '../../includes/header.php';

$stmt = mysqli_prepare($conn, "SELECT po.*, s.name as supplier_name, w.name as warehouse_name, u.full_name as created_by_name FROM purchase_orders po JOIN suppliers s ON po.supplier_id = s.supplier_id JOIN warehouses w ON po.warehouse_id = w.warehouse_id JOIN users u ON po.created_by = u.user_id WHERE po.po_id = ?");
mysqli_stmt_bind_param($stmt, "i", $po_id);
mysqli_stmt_execute($stmt);
$po = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$po) {
    header("Location: index.php");
    exit();
}

$lines = mysqli_query($conn, "
    SELECT pl.*, p.name as product_name, p.sku
    FROM po_line_items pl
    JOIN products p ON pl.product_id = p.product_id
    WHERE pl.po_id = $po_id
");

mysqli_close($conn);

$badges = ['DRAFT' => 'secondary', 'SENT' => 'info', 'CONFIRMED' => 'primary', 'PARTIALLY_RECEIVED' => 'warning', 'RECEIVED' => 'success', 'CLOSED' => 'dark', 'CANCELLED' => 'danger'];
$badge = $badges[$po['status']] ?? 'secondary';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-file-text"></i> PO #<?php echo $po_id; ?> <span class="badge bg-<?php echo $badge; ?>"><?php echo $po['status']; ?></span></h4>
    <a href="print.php?id=<?php echo $po_id; ?>" class="btn btn-dark me-2" target="_blank"> <i class="bi bi-printer"></i> Print PO </a>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>
<?php if($error): ?>
<div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3"><strong>Supplier:</strong><br><?php echo htmlspecialchars($po['supplier_name']); ?></div>
            <div class="col-md-3"><strong>Warehouse:</strong><br><?php echo htmlspecialchars($po['warehouse_name']); ?></div>
            <div class="col-md-3"><strong>Total Amount:</strong><br>Rs. <?php echo number_format($po['total_amount'], 2); ?></div>
            <div class="col-md-3"><strong>Created By:</strong><br><?php echo $po['created_by_name']; ?></div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-header bg-white"><h6 class="mb-0">Line Items</h6></div>
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>Product</th>
                    <th>Unit Cost</th>
                    <th>Ordered</th>
                    <th>Received</th>
                    <th>Outstanding</th>
                </tr>
            </thead>
            <tbody>
                <?php while($line = mysqli_fetch_assoc($lines)): ?>
                <tr>
                    <td><?php echo $line['product_name'] . ' (' . $line['sku'] . ')'; ?></td>
                    <td>Rs. <?php echo number_format($line['unit_cost'], 2); ?></td>
                    <td><?php echo $line['quantity_ordered']; ?></td>
                    <td><?php echo $line['quantity_received']; ?></td>
                    <td><?php echo $line['quantity_ordered'] - $line['quantity_received']; ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <?php if($po['status'] == 'DRAFT'): ?>
            <form method="POST" class="d-inline"><?php echo csrf_field(); ?><input type="hidden" name="action" value="send"><button class="btn btn-info">Supplier ko Bhejo</button></form>
            <form method="POST" class="d-inline"><?php echo csrf_field(); ?><input type="hidden" name="action" value="cancel"><button class="btn btn-outline-danger" onclick="return confirm('Cancel karna hai?')">Cancel Karo</button></form>
        <?php elseif($po['status'] == 'SENT'): ?>
            <form method="POST" class="d-inline"><?php echo csrf_field(); ?><input type="hidden" name="action" value="confirm"><button class="btn btn-primary">Confirm Karo</button></form>
            <form method="POST" class="d-inline"><?php echo csrf_field(); ?><input type="hidden" name="action" value="cancel"><button class="btn btn-outline-danger" onclick="return confirm('Cancel karna hai?')">Cancel Karo</button></form>
        <?php elseif($po['status'] == 'CONFIRMED' || $po['status'] == 'PARTIALLY_RECEIVED'): ?>
            <a href="receive.php?po_id=<?php echo $po_id; ?>" class="btn btn-success">
                <i class="bi bi-box-arrow-in-down"></i> Goods Receive Karo
            </a>
        <?php elseif($po['status'] == 'RECEIVED'): ?>
            <form method="POST" class="d-inline"><?php echo csrf_field(); ?><input type="hidden" name="action" value="close"><button class="btn btn-dark">PO Close Karo</button></form>
        <?php else: ?>
            <p class="text-muted mb-0">Is PO pe koi aur action possible nahi hai.</p>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>