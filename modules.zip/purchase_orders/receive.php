<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/audit.php';

$conn = getConnection();
require_once '../../includes/auth.php'; 
requireRole(['ADMIN', 'MANAGER', 'STAFF']);
$error = "";

if(!isset($_GET['po_id'])) {
    
    header("Location: index.php");
    exit();
}

$po_id = (int)$_GET['po_id'];

$stmt = mysqli_prepare($conn, "SELECT * FROM purchase_orders WHERE po_id = ?");
mysqli_stmt_bind_param($stmt, "i", $po_id);
mysqli_stmt_execute($stmt);
$po = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$po) {
    require_once '../../includes/header.php';
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $location_id = (int)$_POST['location_id'];
    $received = $_POST['received'] ?? [];
    $performed_by = $_SESSION['user_id'];
    $any_received = false;

    foreach($received as $po_line_id => $recv_qty) {
        $recv_qty = (float)$recv_qty;
        if($recv_qty > 0) {
            $po_line_id = (int)$po_line_id;

            $line = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM po_line_items WHERE po_line_id = $po_line_id"));
            $outstanding = $line['quantity_ordered'] - $line['quantity_received'];

            if($recv_qty > $outstanding) {
                $error = "Product ke liye outstanding se zyada quantity nahi receive kar sakte!";
                break;
            }

            $product_id = $line['product_id'];

            // Update inventory
            $check = mysqli_prepare($conn, "SELECT item_id, quantity_on_hand FROM inventory_items WHERE product_id = ? AND location_id = ?");
            mysqli_stmt_bind_param($check, "ii", $product_id, $location_id);
            mysqli_stmt_execute($check);
            $existing = mysqli_fetch_assoc(mysqli_stmt_get_result($check));

            $qty_before = $existing ? $existing['quantity_on_hand'] : 0;
            $qty_after = $qty_before + $recv_qty;

            if($existing) {
                $upd = mysqli_prepare($conn, "UPDATE inventory_items SET quantity_on_hand = ? WHERE item_id = ?");
                mysqli_stmt_bind_param($upd, "di", $qty_after, $existing['item_id']);
                mysqli_stmt_execute($upd);
            } else {
                $ins = mysqli_prepare($conn, "INSERT INTO inventory_items (product_id, location_id, quantity_on_hand) VALUES (?, ?, ?)");
                mysqli_stmt_bind_param($ins, "iid", $product_id, $location_id, $qty_after);
                mysqli_stmt_execute($ins);
            }

            // Movement record
            $mov = mysqli_prepare($conn, "INSERT INTO movement_records (product_id, from_location_id, to_location_id, movement_type, quantity, qty_before, qty_after, reference_type, reference_id, performed_by) VALUES (?, NULL, ?, 'RECEIPT', ?, ?, ?, 'PO', ?, ?)");
            mysqli_stmt_bind_param($mov, "iidddii", $product_id, $location_id, $recv_qty, $qty_before, $qty_after, $po_id, $performed_by);
            mysqli_stmt_execute($mov);

            // Update PO line
            $new_received = $line['quantity_received'] + $recv_qty;
            $updline = mysqli_prepare($conn, "UPDATE po_line_items SET quantity_received = ? WHERE po_line_id = ?");
            mysqli_stmt_bind_param($updline, "di", $new_received, $po_line_id);
            mysqli_stmt_execute($updline);

            // Clear reorder alert if applicable
            $ack = mysqli_prepare($conn, "UPDATE reorder_alerts SET alert_status='ACKNOWLEDGED', acknowledged_at=NOW() WHERE product_id=? AND location_id=? AND alert_status='ACTIVE'");
            mysqli_stmt_bind_param($ack, "ii", $product_id, $location_id);
            mysqli_stmt_execute($ack);

            $any_received = true;
        }
    }

    if($any_received && !$error) {
        // Check overall PO status
        $all_lines = mysqli_query($conn, "SELECT quantity_ordered, quantity_received FROM po_line_items WHERE po_id = $po_id");
        $fully_received = true;
        while($l = mysqli_fetch_assoc($all_lines)) {
            if($l['quantity_received'] < $l['quantity_ordered']) {
                $fully_received = false;
            }
        }
        $new_status = $fully_received ? 'RECEIVED' : 'PARTIALLY_RECEIVED';

        $updpo = mysqli_prepare($conn, "UPDATE purchase_orders SET status = ? WHERE po_id = ?");
        mysqli_stmt_bind_param($updpo, "si", $new_status, $po_id);
        mysqli_stmt_execute($updpo);

        logAudit($conn, $performed_by, 'purchase_orders', $po_id, 'UPDATE', null, ['status' => $new_status, 'action' => 'GOODS_RECEIVED']);

        require_once '../../includes/header.php';
        header("Location: view.php?id=" . $po_id);
        exit();
    }
}

require_once '../../includes/header.php';

$lines = mysqli_query($conn, "
    SELECT pl.*, p.name as product_name, p.sku
    FROM po_line_items pl
    JOIN products p ON pl.product_id = p.product_id
    WHERE pl.po_id = $po_id AND pl.quantity_received < pl.quantity_ordered
");

$locations = mysqli_query($conn, "SELECT location_id, zone_code, bin_code FROM locations WHERE warehouse_id = " . (int)$po['warehouse_id']);

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-box-arrow-in-down"></i> Goods Receive Karo — PO #<?php echo $po_id; ?></h4>
    <a href="view.php?id=<?php echo $po_id; ?>" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label">Stock kahan store hogi (Location) *</label>
                <select name="location_id" class="form-select" required>
                    <option value="">-- Location Select Karo --</option>
                    <?php while($l = mysqli_fetch_assoc($locations)): ?>
                    <option value="<?php echo $l['location_id']; ?>"><?php echo ($l['zone_code'] ?? '') . '/' . ($l['bin_code'] ?? ''); ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Product</th>
                        <th>Ordered</th>
                        <th>Already Received</th>
                        <th>Outstanding</th>
                        <th>Ab Kitna Receive Karna Hai</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(mysqli_num_rows($lines) > 0): ?>
                        <?php while($line = mysqli_fetch_assoc($lines)): ?>
                        <?php $outstanding = $line['quantity_ordered'] - $line['quantity_received']; ?>
                        <tr>
                            <td><?php echo $line['product_name'] . ' (' . $line['sku'] . ')'; ?></td>
                            <td><?php echo $line['quantity_ordered']; ?></td>
                            <td><?php echo $line['quantity_received']; ?></td>
                            <td><?php echo $outstanding; ?></td>
                            <td>
                                <input type="number" name="received[<?php echo $line['po_line_id']; ?>]" class="form-control" value="0" step="0.01" min="0" max="<?php echo $outstanding; ?>">
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center text-muted">Sab products already receive ho chuke hain</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <button type="submit" class="btn btn-success">
                <i class="bi bi-check-circle"></i> Receive Confirm Karo
            </button>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>