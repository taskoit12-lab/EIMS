<?php
session_start();
require_once '../../config/database.php';

if(!isset($_SESSION['user_id'])) {
    header("Location: " . BASE_URL . "login.php");
    exit();
}

if(!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$conn = getConnection();
$po_id = (int)$_GET['id'];

$stmt = mysqli_prepare($conn, "SELECT po.*, s.name as supplier_name, s.contact_person, s.email as supplier_email, s.phone as supplier_phone, s.address as supplier_address, w.name as warehouse_name, w.address as warehouse_address FROM purchase_orders po JOIN suppliers s ON po.supplier_id = s.supplier_id JOIN warehouses w ON po.warehouse_id = w.warehouse_id WHERE po.po_id = ?");
mysqli_stmt_bind_param($stmt, "i", $po_id);
mysqli_stmt_execute($stmt);
$po = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$po) {
    header("Location: index.php");
    exit();
}

$lines = mysqli_query($conn, "
    SELECT pl.*, p.name as product_name, p.sku
    FROM po_line_items pl
    JOIN products p ON pl.product_id = p.product_id
    WHERE pl.po_id = $po_id
");

$company = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM company_settings WHERE id = 1"));

mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Purchase Order #<?php echo $po_id; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 30px; }
        .invoice-header { border-bottom: 3px solid #2c3e50; padding-bottom: 20px; margin-bottom: 20px; }
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="no-print mb-3 text-end">
            <button onclick="window.print()" class="btn btn-dark"><i class="bi bi-printer"></i> Print PO</button>
            <a href="view.php?id=<?php echo $po_id; ?>" class="btn btn-outline-secondary">Wapas Jao</a>
        </div>

        <div class="invoice-header d-flex justify-content-between">
            <div>
                <h3><?php echo htmlspecialchars($company['business_name']); ?></h3>
                <p class="mb-0"><?php echo nl2br(htmlspecialchars($company['address'] ?? '')); ?></p>
                <p class="mb-0"><?php echo htmlspecialchars($company['phone'] ?? ''); ?> <?php echo $company['email'] ? '| ' . htmlspecialchars($company['email']) : ''; ?></p>
                <?php if(!empty($company['gstin'])): ?>
                <p class="mb-0">GSTIN: <?php echo htmlspecialchars($company['gstin']); ?></p>
                <?php endif; ?>
            </div>
            <div class="text-end">
                <h4>PURCHASE ORDER</h4>
                <p class="mb-0">PO #: <?php echo $po_id; ?></p>
                <p class="mb-0">Date: <?php echo date('d-M-Y', strtotime($po['created_at'])); ?></p>
                <?php if($po['expected_delivery_date']): ?>
                <p class="mb-0">Expected Delivery: <?php echo date('d-M-Y', strtotime($po['expected_delivery_date'])); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <div class="row mb-4">
            <div class="col-md-6">
                <h6>Supplier:</h6>
                <p class="mb-0"><strong><?php echo htmlspecialchars($po['supplier_name']); ?></strong></p>
                <p class="mb-0"><?php echo htmlspecialchars($po['contact_person'] ?? ''); ?></p>
                <p class="mb-0"><?php echo htmlspecialchars($po['supplier_phone'] ?? ''); ?></p>
                <p class="mb-0"><?php echo htmlspecialchars($po['supplier_email'] ?? ''); ?></p>
                <p class="mb-0"><?php echo nl2br(htmlspecialchars($po['supplier_address'] ?? '')); ?></p>
            </div>
            <div class="col-md-6">
                <h6>Deliver To:</h6>
                <p class="mb-0"><strong><?php echo htmlspecialchars($po['warehouse_name']); ?></strong></p>
                <p class="mb-0"><?php echo nl2br(htmlspecialchars($po['warehouse_address'] ?? '')); ?></p>
            </div>
        </div>

        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Product</th>
                    <th>SKU</th>
                    <th class="text-end">Qty</th>
                    <th class="text-end">Unit Cost</th>
                    <th class="text-end">Amount</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; $grand_total = 0; while($line = mysqli_fetch_assoc($lines)): ?>
                <?php $amount = $line['quantity_ordered'] * $line['unit_cost']; $grand_total += $amount; ?>
                <tr>
                    <td><?php echo $i++; ?></td>
                    <td><?php echo htmlspecialchars($line['product_name']); ?></td>
                    <td><?php echo htmlspecialchars($line['sku']); ?></td>
                    <td class="text-end"><?php echo $line['quantity_ordered']; ?></td>
                    <td class="text-end">Rs. <?php echo number_format($line['unit_cost'], 2); ?></td>
                    <td class="text-end">Rs. <?php echo number_format($amount, 2); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="5" class="text-end">Grand Total</th>
                    <th class="text-end">Rs. <?php echo number_format($grand_total, 2); ?></th>
                </tr>
            </tfoot>
        </table>

        <?php if(!empty($po['notes'])): ?>
        <div class="mt-3">
            <strong>Notes:</strong>
            <p><?php echo nl2br(htmlspecialchars($po['notes'])); ?></p>
        </div>
        <?php endif; ?>

        <p class="text-muted mt-4">Please confirm receipt of this order and expected delivery timeline.</p>
    </div>
</body>
</html>