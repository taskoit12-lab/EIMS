<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/audit.php';

$conn = getConnection();
require_once '../../includes/auth.php'; 
requireRole(['ADMIN', 'MANAGER', 'STAFF']);
$error = "";

if(!isset($_GET['po_id'])) {
    require_once '../../includes/header.php';
    header("Location: index.php");
    exit();
}

$po_id = (int)$_GET['po_id'];

$stmt = mysqli_prepare($conn, "SELECT * FROM purchase_orders WHERE po_id = ?");
mysqli_stmt_bind_param($stmt, "i", $po_id);
mysqli_stmt_execute($stmt);
$po = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$po) {
    require_once '../../includes/header.php';
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $quantities = $_POST['qty'] ?? [];
    $costs = $_POST['cost'] ?? [];
    $total = 0;
    $added_any = false;

    foreach($quantities as $product_id => $qty) {
        $qty = (float)$qty;
        if($qty > 0) {
            $unit_cost = (float)$costs[$product_id];
            $product_id = (int)$product_id;

            $stmt = mysqli_prepare($conn, "INSERT INTO po_line_items (po_id, product_id, quantity_ordered, unit_cost) VALUES (?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "iidd", $po_id, $product_id, $qty, $unit_cost);
            mysqli_stmt_execute($stmt);

            $total += $qty * $unit_cost;
            $added_any = true;
        }
    }

    if($added_any) {
        $upd = mysqli_prepare($conn, "UPDATE purchase_orders SET total_amount = ? WHERE po_id = ?");
        mysqli_stmt_bind_param($upd, "di", $total, $po_id);
        mysqli_stmt_execute($upd);

        logAudit($conn, $_SESSION['user_id'], 'purchase_orders', $po_id, 'UPDATE', null, ['total_amount' => $total]);

        header("Location: view.php?id=" . $po_id);
        exit();
    } else {
        $error = "Kam se kam ek product ki quantity daalo!";
    }
}

require_once '../../includes/header.php';

$items = mysqli_query($conn, "
    SELECT si.*, p.name as product_name, p.sku
    FROM supplier_items si
    JOIN products p ON si.product_id = p.product_id
    WHERE si.supplier_id = " . (int)$po['supplier_id'] . "
    ORDER BY p.name
");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-list-check"></i> PO #<?php echo $po_id; ?> — Products Add Karo</h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <?php if(mysqli_num_rows($items) > 0): ?>
        <form method="POST">
            <?php echo csrf_field(); ?>
            <table class="table table-hover">
                <thead class="table-light">
                    <tr>
                        <th>Product</th>
                        <th>Unit Cost (Rs.)</th>
                        <th>Quantity Order Karni Hai</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($item = mysqli_fetch_assoc($items)): ?>
                    <tr>
                        <td><?php echo $item['product_name'] . ' (' . $item['sku'] . ')'; ?></td>
                        <td>
                            <input type="number" name="cost[<?php echo $item['product_id']; ?>]" class="form-control" value="<?php echo $item['unit_cost']; ?>" step="0.01" min="0">
                        </td>
                        <td>
                            <input type="number" name="qty[<?php echo $item['product_id']; ?>]" class="form-control" value="0" step="0.01" min="0">
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <button type="submit" class="btn btn-dark">
                <i class="bi bi-check-circle"></i> PO Finalize Karo
            </button>
        </form>
        <?php else: ?>
            <p class="text-muted">Is supplier ke saath koi product linked nahi hai. Pehle <a href="<?php echo BASE_URL; ?>modules/suppliers/index.php">Suppliers</a> mein jaake products link karo.</p>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>