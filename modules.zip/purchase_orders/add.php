<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/audit.php';

$conn = getConnection();
$error = "";
require_once '../../includes/auth.php';
requireRole(['ADMIN', 'MANAGER', 'STAFF']);

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $supplier_id = (int)$_POST['supplier_id'];
    $warehouse_id = (int)$_POST['warehouse_id'];
    $expected_delivery_date = !empty($_POST['expected_delivery_date']) ? $_POST['expected_delivery_date'] : null;
    $notes = trim($_POST['notes']);
    $created_by = $_SESSION['user_id'];

    if(empty($supplier_id) || empty($warehouse_id)) {
        $error = "Supplier aur Warehouse dono select karna zaroori hai!";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO purchase_orders (supplier_id, warehouse_id, status, expected_delivery_date, notes, created_by) VALUES (?, ?, 'DRAFT', ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "iissi", $supplier_id, $warehouse_id, $expected_delivery_date, $notes, $created_by);

        if(mysqli_stmt_execute($stmt)) {
            $new_po_id = mysqli_insert_id($conn);
            logAudit($conn, $created_by, 'purchase_orders', $new_po_id, 'CREATE', null, ['supplier_id' => $supplier_id, 'status' => 'DRAFT']);
            header("Location: add_items.php?po_id=" . $new_po_id);
            exit();
        } else {
            $error = "Kuch galat hua: " . mysqli_error($conn);
        }
    }
}
require_once '../../includes/header.php';

$suppliers = mysqli_query($conn, "SELECT supplier_id, name FROM suppliers ORDER BY name");
$warehouses = mysqli_query($conn, "SELECT warehouse_id, name FROM warehouses ORDER BY name");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-cart-plus"></i> Naya Purchase Order — Step 1</h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Supplier *</label>
                    <select name="supplier_id" class="form-select" required>
                        <option value="">-- Supplier Select Karo --</option>
                        <?php while($s = mysqli_fetch_assoc($suppliers)): ?>
                        <option value="<?php echo $s['supplier_id']; ?>"><?php echo $s['name']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Warehouse (delivery kahan hogi) *</label>
                    <select name="warehouse_id" class="form-select" required>
                        <option value="">-- Warehouse Select Karo --</option>
                        <?php while($w = mysqli_fetch_assoc($warehouses)): ?>
                        <option value="<?php echo $w['warehouse_id']; ?>"><?php echo $w['name']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Expected Delivery Date</label>
                    <input type="date" name="expected_delivery_date" class="form-control">
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Notes</label>
                    <textarea name="notes" class="form-control" rows="2"></textarea>
                </div>
            </div>
            <button type="submit" class="btn btn-dark">
                <i class="bi bi-arrow-right-circle"></i> Aage Badho — Products Add Karo
            </button>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>