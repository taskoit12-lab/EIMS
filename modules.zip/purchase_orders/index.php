<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';

$conn = getConnection();

$orders = mysqli_query($conn, "
    SELECT po.*, s.name as supplier_name, w.name as warehouse_name
    FROM purchase_orders po
    JOIN suppliers s ON po.supplier_id = s.supplier_id
    JOIN warehouses w ON po.warehouse_id = w.warehouse_id
    ORDER BY po.created_at DESC
");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-cart-plus"></i> Purchase Orders</h4>
    <a href="add.php" class="btn btn-dark">
        <i class="bi bi-plus-circle"></i> Naya PO Banao
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>PO #</th>
                    <th>Supplier</th>
                    <th>Warehouse</th>
                    <th>Total Amount</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($orders) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($orders)): ?>
                    <tr>
                        <td>#<?php echo $row['po_id']; ?></td>
                        <td><?php echo $row['supplier_name']; ?></td>
                        <td><?php echo $row['warehouse_name']; ?></td>
                        <td>Rs. <?php echo number_format($row['total_amount'], 2); ?></td>
                        <td>
                            <?php
                            $badges = ['DRAFT' => 'secondary', 'SENT' => 'info', 'CONFIRMED' => 'primary', 'PARTIALLY_RECEIVED' => 'warning', 'RECEIVED' => 'success', 'CLOSED' => 'dark', 'CANCELLED' => 'danger'];
                            $badge = $badges[$row['status']] ?? 'secondary';
                            ?>
                            <span class="badge bg-<?php echo $badge; ?>"><?php echo $row['status']; ?></span>
                        </td>
                        <td><?php echo date('d-M-Y', strtotime($row['created_at'])); ?></td>
                        <td>
                            <a href="view.php?id=<?php echo $row['po_id']; ?>" class="btn btn-sm btn-outline-dark">
                                <i class="bi bi-eye"></i> View
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">
                            Abhi koi purchase order nahi hai. <a href="add.php">Pehla PO banao</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>