<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';

$conn = getConnection();

$suppliers = mysqli_query($conn, "
    SELECT s.*, COUNT(si.supplier_item_id) as item_count
    FROM suppliers s
    LEFT JOIN supplier_items si ON s.supplier_id = si.supplier_id
    GROUP BY s.supplier_id
    ORDER BY s.name
");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-truck"></i> Suppliers</h4>
    <a href="add.php" class="btn btn-dark">
        <i class="bi bi-plus-circle"></i> Naya Supplier Add Karo
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>Naam</th>
                    <th>Contact Person</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Rating</th>
                    <th>Products</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($suppliers) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($suppliers)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['contact_person'] ?? '-'); ?></td>
                        <td><?phpecho htmlspecialchars($row['email'] ?? '-'); ?></td>
                        <td><?php echo htmlspecialchars($row['phone'] ?? '-'); ?></td>
                        <td>
                            <?php if($row['rating'] > 0): ?>
                                <span class="badge bg-warning text-dark"><?php echo $row['rating']; ?> ★</span>
                            <?php else: ?>
                                <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-info"><?php echo $row['item_count']; ?></span>
                        </td>
                        <td>
                            <a href="items.php?supplier_id=<?php echo $row['supplier_id']; ?>" class="btn btn-sm btn-outline-dark">
                                <i class="bi bi-box-seam"></i> Products
                            </a>
                            <a href="edit.php?id=<?php echo $row['supplier_id']; ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-pencil"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">
                            Abhi koi supplier nahi hai. <a href="add.php">Pehla supplier add karo</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>