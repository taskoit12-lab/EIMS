<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
require_once '../../includes/audit.php';
require_once '../../includes/auth.php'; 
requireRole(['ADMIN', 'MANAGER']);

$conn = getConnection();
$error = "";
$success = "";

if(!isset($_GET['supplier_id'])) {
    header("Location: index.php");
    exit();
}

$supplier_id = (int)$_GET['supplier_id'];

$stmt = mysqli_prepare($conn, "SELECT * FROM suppliers WHERE supplier_id = ?");
mysqli_stmt_bind_param($stmt, "i", $supplier_id);
mysqli_stmt_execute($stmt);
$supplier = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$supplier) {
    header("Location: index.php");
    exit();
}

// Product link karo
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $product_id = (int)$_POST['product_id'];
    $unit_cost = (float)$_POST['unit_cost'];
    $lead_time_days = (int)$_POST['lead_time_days'];
    $is_preferred = isset($_POST['is_preferred']) ? 1 : 0;

    $check = mysqli_prepare($conn, "SELECT supplier_item_id FROM supplier_items WHERE supplier_id = ? AND product_id = ?");
    mysqli_stmt_bind_param($check, "ii", $supplier_id, $product_id);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);

    if(mysqli_stmt_num_rows($check) > 0) {
        $error = "Ye product pehle se is supplier se linked hai!";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO supplier_items (supplier_id, product_id, unit_cost, lead_time_days, is_preferred) VALUES (?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "iidii", $supplier_id, $product_id, $unit_cost, $lead_time_days, $is_preferred);

        if(mysqli_stmt_execute($stmt)) {
            $success = "Product link ho gaya!";
        } else {
            $error = "Kuch galat hua: " . mysqli_error($conn);
        }
    }
}

// Remove link
if(isset($_GET['remove'])) {
    $remove_id = (int)$_GET['remove'];
    $stmt = mysqli_prepare($conn, "DELETE FROM supplier_items WHERE supplier_item_id = ?");
    mysqli_stmt_bind_param($stmt, "i", $remove_id);
    mysqli_stmt_execute($stmt);
    logAudit($conn, $_SESSION['user_id'], 'supplier_items', $remove_id, 'DELETE', null, null);
    $success = "Product link remove ho gaya!";
}

$linked_items = mysqli_query($conn, "
    SELECT si.*, p.name as product_name, p.sku
    FROM supplier_items si
    JOIN products p ON si.product_id = p.product_id
    WHERE si.supplier_id = $supplier_id
    ORDER BY p.name
");

$available_products = mysqli_query($conn, "
    SELECT product_id, name, sku FROM products
    WHERE status='ACTIVE' AND product_id NOT IN (
        SELECT product_id FROM supplier_items WHERE supplier_id = $supplier_id
    )
    ORDER BY name
");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-box-seam"></i> Products — <?php echo htmlspecialchars($supplier['name']); ?></h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white">
                <h6 class="mb-0">Naya Product Link Karo</h6>
            </div>
            <div class="card-body">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Product</label>
                        <select name="product_id" class="form-select" required>
                            <option value="">-- Product Select Karo --</option>
                            <?php while($p = mysqli_fetch_assoc($available_products)): ?>
                            <option value="<?php echo $p['product_id']; ?>"><?php echo $p['name'] . ' (' . $p['sku'] . ')'; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Unit Cost (Rs.)</label>
                        <input type="number" name="unit_cost" class="form-control" step="0.01" min="0" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Lead Time (Days)</label>
                        <input type="number" name="lead_time_days" class="form-control" min="0" value="0">
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" name="is_preferred" class="form-check-input" id="preferredCheck">
                        <label class="form-check-label" for="preferredCheck">Preferred Supplier</label>
                    </div>
                    <button type="submit" class="btn btn-dark w-100">
                        <i class="bi bi-link-45deg"></i> Link Karo
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white">
                <h6 class="mb-0">Linked Products</h6>
            </div>
            <div class="card-body">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Product</th>
                            <th>Unit Cost</th>
                            <th>Lead Time</th>
                            <th>Preferred</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($linked_items) > 0): ?>
                            <?php while($row = mysqli_fetch_assoc($linked_items)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['product_name'] . ' (' . $row['sku'] . ')'); ?></td>
                                <td>Rs. <?php echo number_format($row['unit_cost'], 2); ?></td>
                                <td><?php echo $row['lead_time_days']; ?> days</td>
                                <td>
                                    <?php if($row['is_preferred']): ?>
                                        <span class="badge bg-success">Yes</span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="?supplier_id=<?php echo $supplier_id; ?>&remove=<?php echo $row['supplier_item_id']; ?>"
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('Remove karna hai?')">
                                        <i class="bi bi-x-circle"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted">Abhi koi product linked nahi hai</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>