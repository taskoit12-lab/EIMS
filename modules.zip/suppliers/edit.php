<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
require_once '../../includes/auth.php'; 
requireRole(['ADMIN', 'MANAGER']);
require_once '../../includes/audit.php';

$conn = getConnection();
$error = "";
$success = "";

if(!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$supplier_id = (int)$_GET['id'];

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $name = trim($_POST['name']);
    $contact_person = trim($_POST['contact_person']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $payment_terms = trim($_POST['payment_terms']);
    $rating = !empty($_POST['rating']) ? (float)$_POST['rating'] : 0;

    if(empty($name)) {
        $error = "Supplier naam zaroori hai!";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE suppliers SET name=?, contact_person=?, email=?, phone=?, address=?, payment_terms=?, rating=? WHERE supplier_id=?");
        mysqli_stmt_bind_param($stmt, "ssssssdi", $name, $contact_person, $email, $phone, $address, $payment_terms, $rating, $supplier_id);

        if(mysqli_stmt_execute($stmt)) {
            logAudit($conn, $_SESSION['user_id'], 'suppliers', $supplier_id, 'UPDATE', null, ['name' => $name, 'email' => $email]);
            $success = "Supplier update ho gaya!";
        } else {
            $error = "Kuch galat hua: " . mysqli_error($conn);
        }
    }
}

$stmt = mysqli_prepare($conn, "SELECT * FROM suppliers WHERE supplier_id = ?");
mysqli_stmt_bind_param($stmt, "i", $supplier_id);
mysqli_stmt_execute($stmt);
$supplier = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$supplier) {
    header("Location: index.php");
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST' && !$error) {
    $stmt2 = mysqli_prepare($conn, "SELECT * FROM suppliers WHERE supplier_id = ?");
    mysqli_stmt_bind_param($stmt2, "i", $supplier_id);
    mysqli_stmt_execute($stmt2);
    $supplier = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt2));
}

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-pencil-square"></i> Supplier Edit Karo</h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Supplier Naam *</label>
                    <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($supplier['name']); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Contact Person</label>
                    <input type="text" name="contact_person" class="form-control" value="<?php echo htmlspecialchars($supplier['contact_person'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($supplier['email'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Phone</label>
                    <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($supplier['phone'] ?? ''); ?>">
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Address</label>
                    <textarea name="address" class="form-control" rows="2"><?php echo htmlspecialchars($supplier['address'] ?? ''); ?></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Payment Terms</label>
                    <input type="text" name="payment_terms" class="form-control" value="<?php echo htmlspecialchars($supplier['payment_terms'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Rating (0-5)</label>
                    <input type="number" name="rating" class="form-control" step="0.1" min="0" max="5" value="<?php echo $supplier['rating']; ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-dark">
                <i class="bi bi-check-circle"></i> Changes Save Karo
            </button>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>