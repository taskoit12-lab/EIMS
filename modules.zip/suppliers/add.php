<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
require_once '../../includes/auth.php'; 
requireRole(['ADMIN', 'MANAGER']);
require_once '../../includes/audit.php';

$conn = getConnection();
$error = "";
$success = "";

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $name = trim($_POST['name']);
    $contact_person = trim($_POST['contact_person']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $payment_terms = trim($_POST['payment_terms']);
    $rating = !empty($_POST['rating']) ? (float)$_POST['rating'] : 0;

    if(empty($name)) {
        $error = "Supplier naam zaroori hai!";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO suppliers (name, contact_person, email, phone, address, payment_terms, rating) VALUES (?, ?, ?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssssssd", $name, $contact_person, $email, $phone, $address, $payment_terms, $rating);

        if(mysqli_stmt_execute($stmt)) {
            $new_id = mysqli_insert_id($conn);
            logAudit($conn, $_SESSION['user_id'], 'suppliers', $new_id, 'CREATE', null, ['name' => $name, 'email' => $email]);
            $success = "Supplier successfully add ho gaya!";
        } else {
            $error = "Kuch galat hua: " . mysqli_error($conn);
        }
    }
}

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-truck"></i> Naya Supplier Add Karo</h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if($success): ?>
    <div class="alert alert-success"><?php echo $success; ?> <a href="index.php">Wapas list pe jao</a></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Supplier Naam *</label>
                    <input type="text" name="name" class="form-control" placeholder="Jaise: ABC Traders" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Contact Person</label>
                    <input type="text" name="contact_person" class="form-control">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Phone</label>
                    <input type="text" name="phone" class="form-control">
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Address</label>
                    <textarea name="address" class="form-control" rows="2"></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Payment Terms</label>
                    <input type="text" name="payment_terms" class="form-control" placeholder="Jaise: Net 30 days">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Rating (0-5)</label>
                    <input type="number" name="rating" class="form-control" step="0.1" min="0" max="5">
                </div>
            </div>
            <button type="submit" class="btn btn-dark">
                <i class="bi bi-plus-circle"></i> Supplier Add Karo
            </button>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>