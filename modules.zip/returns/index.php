<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';

$conn = getConnection();

$returns = mysqli_query($conn, "
    SELECT r.*, p.name as product_name, p.sku, so.customer_name
    FROM rma_records r
    JOIN products p ON r.product_id = p.product_id
    JOIN sales_orders so ON r.so_id = so.so_id
    ORDER BY r.created_at DESC
");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-arrow-return-left"></i> Returns / RMA</h4>
    <a href="add.php" class="btn btn-dark">
        <i class="bi bi-plus-circle"></i> Nayi Return Karo
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>RMA #</th>
                    <th>SO #</th>
                    <th>Customer</th>
                    <th>Product</th>
                    <th>Qty Returned</th>
                    <th>Reason</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($returns) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($returns)): ?>
                    <tr>
                        <td>#<?php echo $row['rma_id']; ?></td>
                        <td>#<?php echo $row['so_id']; ?></td>
                        <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['product_name'] . ' (' . $row['sku'] . ')'); ?></td>
                        <td><?php echo $row['quantity_returned']; ?></td>
                        <td><?php echo $row['reason_code']; ?></td>
                        <td>
                            <?php
                            $badges = ['INITIATED' => 'secondary', 'RECEIVED' => 'info', 'INSPECTED' => 'warning', 'CLOSED' => 'success'];
                            $badge = $badges[$row['status']] ?? 'secondary';
                            ?>
                            <span class="badge bg-<?php echo $badge; ?>"><?php echo $row['status']; ?></span>
                        </td>
                        <td>
                            <a href="view.php?id=<?php echo $row['rma_id']; ?>" class="btn btn-sm btn-outline-dark">
                                <i class="bi bi-eye"></i> View
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted">
                            Abhi koi return nahi hai. <a href="add.php">Pehli return banao</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>