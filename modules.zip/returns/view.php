<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/audit.php';

$conn = getConnection();
$error = "";

if(!isset($_GET['id'])) {
    require_once '../../includes/header.php';
    header("Location: index.php");
    exit();
}

$rma_id = (int)$_GET['id'];

if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    csrf_verify();
    $action = $_POST['action'];
    $performed_by = $_SESSION['user_id'];

    if($action == 'receive') {
        $stmt = mysqli_prepare($conn, "UPDATE rma_records SET status = 'RECEIVED' WHERE rma_id = ?");
        mysqli_stmt_bind_param($stmt, "i", $rma_id);
        mysqli_stmt_execute($stmt);
        logAudit($conn, $performed_by, 'rma_records', $rma_id, 'UPDATE', null, ['status' => 'RECEIVED']);
    }

    if($action == 'inspect') {
        $item_condition = $_POST['item_condition'];
        $disposition = $_POST['disposition'];
        $location_id = !empty($_POST['location_id']) ? (int)$_POST['location_id'] : null;

        $stmt = mysqli_prepare($conn, "UPDATE rma_records SET status = 'INSPECTED', item_condition = ?, disposition = ?, inspected_by = ? WHERE rma_id = ?");
        mysqli_stmt_bind_param($stmt, "ssii", $item_condition, $disposition, $performed_by, $rma_id);
        mysqli_stmt_execute($stmt);

        if($disposition == 'RESTOCK' && $location_id) {
            $rma = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM rma_records WHERE rma_id = $rma_id"));
            $product_id = $rma['product_id'];
            $qty_returned = $rma['quantity_returned'];

            $check = mysqli_prepare($conn, "SELECT item_id, quantity_on_hand FROM inventory_items WHERE product_id = ? AND location_id = ?");
            mysqli_stmt_bind_param($check, "ii", $product_id, $location_id);
            mysqli_stmt_execute($check);
            $existing = mysqli_fetch_assoc(mysqli_stmt_get_result($check));

            $qty_before = $existing ? $existing['quantity_on_hand'] : 0;
            $qty_after = $qty_before + $qty_returned;

            if($existing) {
                $upd = mysqli_prepare($conn, "UPDATE inventory_items SET quantity_on_hand = ? WHERE item_id = ?");
                mysqli_stmt_bind_param($upd, "di", $qty_after, $existing['item_id']);
                mysqli_stmt_execute($upd);
            } else {
                $ins = mysqli_prepare($conn, "INSERT INTO inventory_items (product_id, location_id, quantity_on_hand) VALUES (?, ?, ?)");
                mysqli_stmt_bind_param($ins, "iid", $product_id, $location_id, $qty_after);
                mysqli_stmt_execute($ins);
            }

            $mov = mysqli_prepare($conn, "INSERT INTO movement_records (product_id, from_location_id, to_location_id, movement_type, quantity, qty_before, qty_after, reference_type, reference_id, performed_by) VALUES (?, NULL, ?, 'RESTOCK', ?, ?, ?, 'RMA', ?, ?)");
            mysqli_stmt_bind_param($mov, "iidddii", $product_id, $location_id, $qty_returned, $qty_before, $qty_after, $rma_id, $performed_by);
            mysqli_stmt_execute($mov);
        }

        logAudit($conn, $performed_by, 'rma_records', $rma_id, 'UPDATE', null, ['status' => 'INSPECTED', 'disposition' => $disposition]);
    }

    if($action == 'close') {
        $stmt = mysqli_prepare($conn, "UPDATE rma_records SET status = 'CLOSED' WHERE rma_id = ?");
        mysqli_stmt_bind_param($stmt, "i", $rma_id);
        mysqli_stmt_execute($stmt);
        logAudit($conn, $performed_by, 'rma_records', $rma_id, 'UPDATE', null, ['status' => 'CLOSED']);
    }
}

require_once '../../includes/header.php';

$stmt = mysqli_prepare($conn, "SELECT r.*, p.name as product_name, p.sku, so.customer_name, u.full_name as inspected_by_name FROM rma_records r JOIN products p ON r.product_id = p.product_id JOIN sales_orders so ON r.so_id = so.so_id LEFT JOIN users u ON r.inspected_by = u.user_id WHERE r.rma_id = ?");
mysqli_stmt_bind_param($stmt, "i", $rma_id);
mysqli_stmt_execute($stmt);
$rma = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$rma) {
    header("Location: index.php");
    exit();
}

$locations = mysqli_query($conn, "SELECT l.location_id, w.name as wname, l.zone_code, l.bin_code FROM locations l JOIN warehouses w ON l.warehouse_id = w.warehouse_id");

mysqli_close($conn);

$badges = ['INITIATED' => 'secondary', 'RECEIVED' => 'info', 'INSPECTED' => 'warning', 'CLOSED' => 'success'];
$badge = $badges[$rma['status']] ?? 'secondary';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-arrow-return-left"></i> RMA #<?php echo $rma_id; ?> <span class="badge bg-<?php echo $badge; ?>"><?php echo $rma['status']; ?></span></h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3"><strong>SO #:</strong><br><?php echo $rma['so_id']; ?></div>
            <div class="col-md-3"><strong>Customer:</strong><br><?php echo htmlspecialchars($rma['customer_name']); ?></div>
            <div class="col-md-3"><strong>Product:</strong><br><?php echo htmlspecialchars($rma['product_name'] . ' (' . $rma['sku'] . ')'); ?></div>
            <div class="col-md-3"><strong>Qty Returned:</strong><br><?php echo $rma['quantity_returned']; ?></div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-3"><strong>Reason:</strong><br><?php echo $rma['reason_code']; ?></div>
            <div class="col-md-3"><strong>Condition:</strong><br><?php echo $rma['item_condition'] ?? '-'; ?></div>
            <div class="col-md-3"><strong>Disposition:</strong><br><?php echo $rma['disposition'] ?? '-'; ?></div>
            <div class="col-md-3"><strong>Inspected By:</strong><br><?php echo $rma['inspected_by_name'] ?? '-'; ?></div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <?php if($rma['status'] == 'INITIATED'): ?>
            <form method="POST"><input type="hidden" name="action" value="receive"><button class="btn btn-info">Item Receive Kiya</button></form>

        <?php elseif($rma['status'] == 'RECEIVED'): ?>
            <h6>Inspection Karo</h6>
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="inspect">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Item Condition *</label>
                        <select name="item_condition" class="form-select" required>
                            <option value="GOOD">Good</option>
                            <option value="DAMAGED">Damaged</option>
                            <option value="EXPIRED">Expired</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label class="form-label">Disposition *</label>
                        <select name="disposition" id="disposition" class="form-select" required onchange="toggleLocation()">
                            <option value="RESTOCK">Restock (wapas stock mein daalo)</option>
                            <option value="SCRAP">Scrap (waste kar do)</option>
                            <option value="RETURN_TO_SUPPLIER">Return to Supplier</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3" id="locationField">
                        <label class="form-label">Restock Location</label>
                        <select name="location_id" class="form-select">
                            <option value="">-- Location --</option>
                            <?php while($l = mysqli_fetch_assoc($locations)): ?>
                            <option value="<?php echo $l['location_id']; ?>"><?php echo $l['wname'] . ' - ' . ($l['zone_code'] ?? '') . '/' . ($l['bin_code'] ?? ''); ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                </div>
                <button type="submit" class="btn btn-warning">Inspection Complete Karo</button>
            </form>
            <script>
            function toggleLocation() {
                var val = document.getElementById('disposition').value;
                document.getElementById('locationField').style.display = (val == 'RESTOCK') ? 'block' : 'none';
            }
            </script>

        <?php elseif($rma['status'] == 'INSPECTED'): ?>
            <form method="POST"><?php echo csrf_field(); ?><input type="hidden" name="action" value="close"><button class="btn btn-success">RMA Close Karo</button></form>

        <?php else: ?>
            <p class="text-muted mb-0">Ye RMA close ho chuka hai.</p>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>