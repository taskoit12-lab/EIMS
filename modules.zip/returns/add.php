<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/audit.php';

$conn = getConnection();
require_once '../../includes/auth.php'; 
requireRole(['ADMIN', 'MANAGER', 'STAFF']);
$error = "";

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $so_id = (int)$_POST['so_id'];
    $product_id = (int)$_POST['product_id'];
    $quantity_returned = (float)$_POST['quantity_returned'];
    $reason_code = $_POST['reason_code'];
    $notes = trim($_POST['notes']);

    if(empty($so_id) || empty($product_id) || $quantity_returned <= 0) {
        $error = "Sales Order, Product aur Quantity (0 se zyada) zaroori hain!";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO rma_records (so_id, product_id, quantity_returned, reason_code, status, notes) VALUES (?, ?, ?, ?, 'INITIATED', ?)");
        mysqli_stmt_bind_param($stmt, "iidss", $so_id, $product_id, $quantity_returned, $reason_code, $notes);

        if(mysqli_stmt_execute($stmt)) {
            $new_id = mysqli_insert_id($conn);
            logAudit($conn, $_SESSION['user_id'], 'rma_records', $new_id, 'CREATE', null, ['so_id' => $so_id, 'reason_code' => $reason_code]);
            header("Location: view.php?id=" . $new_id);
            exit();
        } else {
            $error = "Kuch galat hua: " . mysqli_error($conn);
        }
    }
}

require_once '../../includes/header.php';

$delivered_orders = mysqli_query($conn, "
    SELECT so.so_id, so.customer_name, sl.product_id, sl.quantity_fulfilled, p.name as product_name, p.sku
    FROM sales_orders so
    JOIN so_line_items sl ON so.so_id = sl.so_id
    JOIN products p ON sl.product_id = p.product_id
    WHERE so.status IN ('DISPATCHED', 'DELIVERED') AND sl.quantity_fulfilled > 0
    ORDER BY so.so_id DESC
");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-arrow-return-left"></i> Nayi Return Banao</h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <?php if(mysqli_num_rows($delivered_orders) > 0): ?>
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-12 mb-3">
                    <label class="form-label">Order + Product (jo dispatch/deliver ho chuka hai) *</label>
                    <select name="so_product" id="soProduct" class="form-select" required onchange="fillHidden()">
                        <option value="">-- Select Karo --</option>
                        <?php while($o = mysqli_fetch_assoc($delivered_orders)): ?>
                        <option value="<?php echo $o['so_id']; ?>|<?php echo $o['product_id']; ?>">
                            SO #<?php echo $o['so_id']; ?> — <?php echo $o['customer_name']; ?> — <?php echo $o['product_name']; ?> (<?php echo $o['sku']; ?>) — Dispatched Qty: <?php echo $o['quantity_fulfilled']; ?>
                        </option>
                        <?php endwhile; ?>
                    </select>
                    <input type="hidden" name="so_id" id="soId">
                    <input type="hidden" name="product_id" id="productId">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Quantity Return Ho Rahi Hai *</label>
                    <input type="number" name="quantity_returned" class="form-control" step="0.01" min="0.01" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Reason *</label>
                    <select name="reason_code" class="form-select" required>
                        <option value="DAMAGED">Damaged</option>
                        <option value="WRONG_ITEM">Wrong Item</option>
                        <option value="NOT_REQUIRED">Not Required</option>
                        <option value="EXPIRED">Expired</option>
                        <option value="OTHER">Other</option>
                    </select>
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Notes</label>
                    <textarea name="notes" class="form-control" rows="2"></textarea>
                </div>
            </div>
            <button type="submit" class="btn btn-dark">
                <i class="bi bi-check-circle"></i> Return Create Karo
            </button>
        </form>
        <script>
        function fillHidden() {
            var val = document.getElementById('soProduct').value;
            var parts = val.split('|');
            document.getElementById('soId').value = parts[0] || '';
            document.getElementById('productId').value = parts[1] || '';
        }
        </script>
        <?php else: ?>
            <p class="text-muted">Koi dispatched/delivered order nahi hai return karne ke liye.</p>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>