<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
require_once '../../includes/auth.php'; 
requireRole(['ADMIN', 'MANAGER']);
require_once '../../includes/audit.php';

$conn = getConnection();
$error = "";
$success = "";

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $name = trim($_POST['name']);
    $address = trim($_POST['address']);
    $city = trim($_POST['city']);
    $manager_id = !empty($_POST['manager_id']) ? (int)$_POST['manager_id'] : null;

    if(empty($name)) {
        $error = "Warehouse naam zaroori hai!";
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO warehouses (name, address, city, manager_id) VALUES (?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sssi", $name, $address, $city, $manager_id);

        if(mysqli_stmt_execute($stmt)) {
            $new_id = mysqli_insert_id($conn);
            logAudit($conn, $_SESSION['user_id'], 'warehouses', $new_id, 'CREATE', null, ['name' => $name, 'city' => $city]);
            $success = "Warehouse successfully add ho gaya!";
        } else {
            $error = "Kuch galat hua: " . mysqli_error($conn);
        }
    }
}

$managers = mysqli_query($conn, "SELECT user_id, full_name FROM users WHERE role IN ('ADMIN','MANAGER') AND status='ACTIVE' ORDER BY full_name");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-building-add"></i> Naya Warehouse Add Karo</h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if($success): ?>
    <div class="alert alert-success"><?php echo $success; ?> <a href="index.php">Wapas list pe jao</a></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Warehouse Naam *</label>
                    <input type="text" name="name" class="form-control" placeholder="Jaise: Main Warehouse" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">City</label>
                    <input type="text" name="city" class="form-control" placeholder="Jaise: Jaipur">
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Address</label>
                    <textarea name="address" class="form-control" rows="2"></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Manager</label>
                    <select name="manager_id" class="form-select">
                        <option value="">-- Koi Manager Nahi --</option>
                        <?php while($m = mysqli_fetch_assoc($managers)): ?>
                        <option value="<?php echo $m['user_id']; ?>"><?php echo $m['full_name']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-dark">
                <i class="bi bi-plus-circle"></i> Warehouse Add Karo
            </button>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>