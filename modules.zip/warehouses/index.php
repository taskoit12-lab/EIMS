<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';

$conn = getConnection();

$warehouses = mysqli_query($conn, "
    SELECT w.*, u.full_name as manager_name, COUNT(l.location_id) as location_count
    FROM warehouses w
    LEFT JOIN users u ON w.manager_id = u.user_id
    LEFT JOIN locations l ON w.warehouse_id = l.warehouse_id
    GROUP BY w.warehouse_id
    ORDER BY w.name
");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-building"></i> Warehouses</h4>
    <a href="add.php" class="btn btn-dark">
        <i class="bi bi-plus-circle"></i> Naya Warehouse Add Karo
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table class="table table-hover">
            <thead class="table-light">
                <tr>
                    <th>Naam</th>
                    <th>City</th>
                    <th>Address</th>
                    <th>Manager</th>
                    <th>Locations</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($warehouses) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($warehouses)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['city'] ?? '-'); ?></td>
                        <td><?php echo htmlspecialchars($row['address'] ?? '-'); ?></td>
                        <td><?php echo $row['manager_name'] ?? '-'; ?></td>
                        <td>
                            <span class="badge bg-info"><?php echo $row['location_count']; ?></span>
                        </td>
                        <td>
                            <a href="locations.php?warehouse_id=<?php echo $row['warehouse_id']; ?>" class="btn btn-sm btn-outline-dark">
                                <i class="bi bi-geo-alt"></i> Locations
                            </a>
                            <a href="edit.php?id=<?php echo $row['warehouse_id']; ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bi bi-pencil"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted">
                            Abhi koi warehouse nahi hai. <a href="add.php">Pehla warehouse add karo</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>