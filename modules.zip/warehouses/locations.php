<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
require_once '../../includes/audit.php';
require_once '../../includes/auth.php'; 
requireRole(['ADMIN', 'MANAGER']);

$conn = getConnection();
$error = "";
$success = "";

if(!isset($_GET['warehouse_id'])) {
    header("Location: index.php");
    exit();
}

$warehouse_id = (int)$_GET['warehouse_id'];

$stmt = mysqli_prepare($conn, "SELECT * FROM warehouses WHERE warehouse_id = ?");
mysqli_stmt_bind_param($stmt, "i", $warehouse_id);
mysqli_stmt_execute($stmt);
$warehouse = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if(!$warehouse) {
    header("Location: index.php");
    exit();
}

// Location add karo
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $zone_code = trim($_POST['zone_code']);
    $bin_code = trim($_POST['bin_code']);
    $location_type = $_POST['location_type'];
    $capacity = !empty($_POST['capacity']) ? (float)$_POST['capacity'] : null;

    $stmt = mysqli_prepare($conn, "INSERT INTO locations (warehouse_id, zone_code, bin_code, location_type, capacity) VALUES (?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "isssd", $warehouse_id, $zone_code, $bin_code, $location_type, $capacity);

    if(mysqli_stmt_execute($stmt)) {
        $success = "Location add ho gayi!";
    } else {
        $error = "Kuch galat hua: " . mysqli_error($conn);
    }
}

// Delete location
if(isset($_GET['delete'])) {
    $delete_id = (int)$_GET['delete'];

    $check = mysqli_prepare($conn, "SELECT item_id FROM inventory_items WHERE location_id = ?");
mysqli_stmt_bind_param($check, "i", $delete_id);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);

    if(mysqli_stmt_num_rows($check) > 0) {
        $error = "Yeh location delete nahi ho sakti — isme stock hai!";
    } else {
        $stmt = mysqli_prepare($conn, "DELETE FROM locations WHERE location_id = ?");
        mysqli_stmt_bind_param($stmt, "i", $delete_id);
        mysqli_stmt_execute($stmt);
        logAudit($conn, $_SESSION['user_id'], 'locations', $delete_id, 'DELETE', null, null);
        $success = "Location delete ho gayi!";
    }
}

$locations = mysqli_query($conn, "SELECT * FROM locations WHERE warehouse_id = $warehouse_id ORDER BY zone_code");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-geo-alt"></i> Locations — <?php echo htmlspecialchars($warehouse['name']); ?></h4>
    <a href="index.php" class="btn btn-outline-dark">
        <i class="bi bi-arrow-left"></i> Wapas Jao
    </a>
</div>

<?php if($error): ?>
    <div class="alert alert-danger"><?php echo $error; ?></div>
<?php endif; ?>

<?php if($success): ?>
    <div class="alert alert-success"><?php echo $success; ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white">
                <h6 class="mb-0">Nayi Location Add Karo</h6>
            </div>
            <div class="card-body">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Zone Code</label>
                        <input type="text" name="zone_code" class="form-control" placeholder="Jaise: A1">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Bin Code</label>
                        <input type="text" name="bin_code" class="form-control" placeholder="Jaise: A1-02">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Type</label>
                        <select name="location_type" class="form-select">
                            <option value="RACK">RACK</option>
                            <option value="FLOOR">FLOOR</option>
                            <option value="COLD">COLD</option>
                            <option value="QUARANTINE">QUARANTINE</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Capacity</label>
                        <input type="number" name="capacity" class="form-control" step="0.01" min="0">
                    </div>
                    <button type="submit" class="btn btn-dark w-100">
                        <i class="bi bi-plus-circle"></i> Add Location
                    </button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white">
                <h6 class="mb-0">Saari Locations</h6>
            </div>
            <div class="card-body">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Zone</th>
                            <th>Bin</th>
                            <th>Type</th>
                            <th>Capacity</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($locations) > 0): ?>
                            <?php while($row = mysqli_fetch_assoc($locations)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($u['full_name']); ?></td>
                                <td><?php echo $row['bin_code'] ?? '-'; ?></td>
                                <td><span class="badge bg-secondary"><?php echo $row['location_type']; ?></span></td>
                                <td><?php echo $row['capacity'] ?? '-'; ?></td>
                                <td>
                                    <a href="?warehouse_id=<?php echo $warehouse_id; ?>&delete=<?php echo $row['location_id']; ?>"
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('Delete karna hai?')">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted">Abhi koi location nahi hai</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>