<?php
session_start();
require_once '../../config/database.php';
require_once '../../includes/header.php';
require_once '../../includes/auth.php';
requireRole(['ADMIN']);

if($_SESSION['role'] != 'ADMIN') {
    header("Location: " . BASE_URL . "index.php");
    exit();
}

$conn = getConnection();

$logs = mysqli_query($conn, "
    SELECT a.*, u.full_name
    FROM audit_log a
    LEFT JOIN users u ON a.user_id = u.user_id
    ORDER BY a.occurred_at DESC
    LIMIT 100
");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-journal-text"></i> Audit Log</h4>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table class="table table-hover table-sm">
            <thead class="table-light">
                <tr>
                    <th>Time</th>
                    <th>User</th>
                    <th>Entity</th>
                    <th>Entity ID</th>
                    <th>Action</th>
                    <th>Details</th>
                    <th>IP</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($logs) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($logs)): ?>
                    <tr>
                        <td><?php echo date('d-M-Y h:i A', strtotime($row['occurred_at'])); ?></td>
                        <td><?php echo $row['full_name'] ?? 'Unknown'; ?></td>
                        <td><?php echo $row['entity_type']; ?></td>
                        <td>#<?php echo $row['entity_id']; ?></td>
                        <td>
                            <?php
                            $badge = 'secondary';
                            if($row['action'] == 'CREATE') $badge = 'success';
                            if($row['action'] == 'UPDATE') $badge = 'warning';
                            if($row['action'] == 'DELETE') $badge = 'danger';
                            ?>
                            <span class="badge bg-<?php echo $badge; ?>"><?php echo $row['action']; ?></span>
                        </td>
                        <td>
                            <small class="text-muted">
                                <?php echo $row['new_value'] ? htmlspecialchars(substr($row['new_value'], 0, 80)) : '-'; ?>
                            </small>
                        </td>
                        <td><?php echo $row['ip_address']; ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">Abhi koi audit log nahi hai</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>