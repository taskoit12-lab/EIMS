<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
require_once '../../includes/auth.php';
require_once '../../includes/audit.php';

requireRole(['ADMIN']);

$conn = getConnection();
$error = "";
$success = "";

// Naya user add karo
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_user'])) {
    csrf_verify();
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    if(empty($full_name) || empty($email) || empty($password)) {
        $error = "Sab fields zaroori hain!";
    } else {
        $check = mysqli_prepare($conn, "SELECT user_id FROM users WHERE email = ?");
        mysqli_stmt_bind_param($check, "s", $email);
        mysqli_stmt_execute($check);
        mysqli_stmt_store_result($check);

        if(mysqli_stmt_num_rows($check) > 0) {
            $error = "Ye email pehle se registered hai!";
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = mysqli_prepare($conn, "INSERT INTO users (full_name, email, password, role, status) VALUES (?, ?, ?, ?, 'ACTIVE')");
            mysqli_stmt_bind_param($stmt, "ssss", $full_name, $email, $hash, $role);

            if(mysqli_stmt_execute($stmt)) {
                $new_id = mysqli_insert_id($conn);
                logAudit($conn, $_SESSION['user_id'], 'users', $new_id, 'CREATE', null, ['full_name' => $full_name, 'role' => $role]);
                $success = "User successfully add ho gaya!";
            } else {
                $error = "Kuch galat hua: " . mysqli_error($conn);
            }
        }
    }
}

// Role change / status toggle
if(isset($_GET['toggle'])) {
    $uid = (int)$_GET['toggle'];
    $u = mysqli_fetch_assoc(mysqli_query($conn, "SELECT status FROM users WHERE user_id = $uid"));
    $new_status = ($u['status'] == 'ACTIVE') ? 'INACTIVE' : 'ACTIVE';
    $stmt = mysqli_prepare($conn, "UPDATE users SET status = ? WHERE user_id = ?");
    mysqli_stmt_bind_param($stmt, "si", $new_status, $uid);
    mysqli_stmt_execute($stmt);
    logAudit($conn, $_SESSION['user_id'], 'users', $uid, 'UPDATE', null, ['status' => $new_status]);
    $success = "User status update ho gaya!";
}
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['reset_password'])) { 
    csrf_verify(); $reset_uid = (int)$_POST['reset_user_id']; $new_pass = $_POST['new_password']; 
    if(strlen($new_pass) < 4) {
         $error = "Password kam se kam 4 characters ka hona chahiye!"; 
         } else {
            $hash = password_hash($new_pass, PASSWORD_BCRYPT);
            $stmt = mysqli_prepare($conn, "UPDATE users SET password = ? WHERE user_id = ?"); mysqli_stmt_bind_param($stmt, "si", $hash, $reset_uid); mysqli_stmt_execute($stmt);
            logAudit($conn, $_SESSION['user_id'], 'users', $reset_uid, 'UPDATE', null, ['action' => 'PASSWORD_RESET']);
            $success = "Password reset ho gaya!"; } }
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_role'])) {
    csrf_verify();
    $uid = (int)$_POST['user_id'];
    $new_role = $_POST['new_role'];
    $stmt = mysqli_prepare($conn, "UPDATE users SET role = ? WHERE user_id = ?");
    mysqli_stmt_bind_param($stmt, "si", $new_role, $uid);
    mysqli_stmt_execute($stmt);
    logAudit($conn, $_SESSION['user_id'], 'users', $uid, 'UPDATE', null, ['role' => $new_role]);
    $success = "Role update ho gaya!";
}

$users = mysqli_query($conn, "SELECT * FROM users ORDER BY full_name");

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-people"></i> User Management</h4>
</div>

<?php if($error): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
<?php if($success): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>

<div class="row">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white"><h6 class="mb-0">Naya User Add Karo</h6></div>
            <div class="card-body">
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label class="form-label">Full Name *</label>
                        <input type="text" name="full_name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email *</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password *</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Role *</label>
                        <select name="role" class="form-select" required>
                            <option value="ADMIN">Admin</option>
                            <option value="MANAGER">Manager</option>
                            <option value="STAFF" selected>Staff</option>
                            <option value="VIEWER">Viewer</option>
                        </select>
                    </div>
                    <button type="submit" name="add_user" class="btn btn-dark w-100">Add User</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white"><h6 class="mb-0">Saare Users</h6></div>
            <div class="card-body">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr><th>Naam</th><th>Email</th><th>Role</th><th>Status</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                        <?php while($u = mysqli_fetch_assoc($users)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($u['full_name']); ?></td>
                            <td><?php echo $u['email']; ?></td>
                            <td>
                                <form method="POST" class="d-flex gap-1">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="user_id" value="<?php echo $u['user_id']; ?>">
                                    <select name="new_role" class="form-select form-select-sm" onchange="this.form.submit()">
                                        <?php foreach(['ADMIN','MANAGER','STAFF','VIEWER'] as $r): ?>
                                        <option value="<?php echo $r; ?>" <?php echo ($r == $u['role']) ? 'selected' : ''; ?>><?php echo $r; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <input type="hidden" name="change_role" value="1">
                                </form>
                            </td>
                            <td>
                                <?php if($u['status'] == 'ACTIVE'): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($u['user_id'] != $_SESSION['user_id']): ?>
                                <a href="?toggle=<?php echo $u['user_id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Status change karna hai?')">
                                    <?php echo $u['status'] == 'ACTIVE' ? 'Deactivate' : 'Activate'; ?>
                                </a>
                                <?php else: ?>
                                    <span class="text-muted small">Ye tum ho</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="card border-0 shadow-sm mt-4"> <div class="card-header bg-white"><h6 class="mb-0">User Password Reset Karo</h6></div> <div class="card-body"> <form method="POST" class="row g-2 align-items-end"> <?php echo csrf_field(); ?> <div class="col-md-5"> <label class="form-label">User Select Karo</label> <select name="reset_user_id" class="form-select" required> <option value="">-- Select Karo --</option> <?php mysqli_data_seek($users, 0); while($u2 = mysqli_fetch_assoc($users)): ?> <option value="<?php echo $u2['user_id']; ?>"><?php echo htmlspecialchars($u2['full_name'] . ' (' . $u2['email'] . ')'); ?></option> <?php endwhile; ?> </select> </div> <div class="col-md-5"> <label class="form-label">Naya Password</label> <input type="text" name="new_password" class="form-control" placeholder="Kam se kam 4 characters" required> </div> <div class="col-md-2"> <button type="submit" name="reset_password" class="btn btn-warning w-100">Reset Karo</button> </div> </form> </div> </div>
<?php require_once '../../includes/footer.php'; ?>