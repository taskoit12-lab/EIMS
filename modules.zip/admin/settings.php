<?php
session_start();
require_once '../../includes/csrf.php';
require_once '../../config/database.php';
require_once '../../includes/header.php';
require_once '../../includes/auth.php';
require_once '../../includes/audit.php';

requireRole(['ADMIN']);

$conn = getConnection();
$error = "";
$success = "";

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $business_name = trim($_POST['business_name']);
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $gstin = trim($_POST['gstin']);
    $upi_id = trim($_POST['upi_id']);

    if(empty($business_name)) {
        $error = "Business naam zaroori hai!";
    } else {
        $stmt = mysqli_prepare($conn, "UPDATE company_settings SET business_name=?, address=?, phone=?, email=?, gstin=?, upi_id=? WHERE id=1");
        mysqli_stmt_bind_param($stmt, "ssssss", $business_name, $address, $phone, $email, $gstin, $upi_id);

        if(mysqli_stmt_execute($stmt)) {
            logAudit($conn, $_SESSION['user_id'], 'company_settings', 1, 'UPDATE', null, ['business_name' => $business_name]);
            $success = "Settings save ho gaye!";
        } else {
            $error = "Kuch galat hua: " . mysqli_error($conn);
        }
    }
}

$settings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM company_settings WHERE id = 1"));

mysqli_close($conn);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h4><i class="bi bi-gear"></i> Business Settings</h4>
</div>

<?php if($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
<?php if($success): ?><div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div><?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Business Naam *</label>
                    <input type="text" name="business_name" class="form-control" value="<?php echo htmlspecialchars($settings['business_name']); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Phone</label>
                    <input type="text" name="phone" class="form-control" value="<?php echo htmlspecialchars($settings['phone'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($settings['email'] ?? ''); ?>">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">GSTIN (agar hai)</label>
                    <input type="text" name="gstin" class="form-control" value="<?php echo htmlspecialchars($settings['gstin'] ?? ''); ?>" placeholder="Optional">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">UPI ID</label>
                    <input type="text" name="upi_id" class="form-control" value="<?php echo htmlspecialchars($settings['upi_id'] ?? ''); ?>" placeholder="Jaise: 9876543210@paytm">
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Address</label>
                    <textarea name="address" class="form-control" rows="2"><?php echo htmlspecialchars($settings['address'] ?? ''); ?></textarea>
                </div>
            </div>
            <button type="submit" class="btn btn-dark">
                <i class="bi bi-check-circle"></i> Settings Save Karo
            </button>
        </form>
    </div>
</div>

<?php require_once '../../includes/footer.php'; ?>